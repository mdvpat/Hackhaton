AD.COMPANY2 — anonymized SharpHound v5 export
=============================================
Domain:      AD.COMPANY2
Format:      SharpHound v5 (7 json files: users, groups, computers, ous,
             containers, domains, gpos)
Principals:  113   Edges (canonicalized): 836
Capabilities: 769 direct · 689 inherited · 108 high-value edges
Notable:     DCSync held by Builtin ADMINISTRATORS and ONE ordinary user
             (requires GetChanges AND GetChangesAll on the domain object)

The de-anonymization map is NOT included and never should be: this package is
safe to share, the mapping is local-only.

Caveat: the export carries no allow/deny information (every ACE has only
RightName/IsInherited/PrincipalSID/PrincipalType), so all capability counts are
an upper bound — "held" is not "held and enforced".

Analyze:
  python3 -m harness.surface_agent --canonicalize --input AD.COMPANY2 --out graph.json
  python3 -m harness.surface_agent --capabilities  --input AD.COMPANY2 --out ledger.json
  python3 scripts/bh_capability_report.py --graph graph.json --ledger ledger.json \
      --out CAPABILITIES.md
