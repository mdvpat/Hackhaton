"""Outbound HTTP proxy support for the harness.

CINECA Leonardo compute nodes have no direct internet: outbound traffic must go
through the shared hackathon proxy. Local endpoints (the model bridge, a local
embedding server) must bypass it, so ``NO_PROXY`` always includes loopback.

Usage:
    from harness.proxy import apply
    apply()                                  # use HTTPS_PROXY/HTTP_PROXY from the env
    apply("http://hackathon:pw@10.99.0.7:24817")

    python3 -m harness.surface_agent ... --proxy http://hackathon:pw@10.99.0.7:24817
"""
from __future__ import annotations

import os
from urllib.parse import urlsplit

LOOPBACK = ("127.0.0.1", "localhost", "::1")
DEFAULT_NO_PROXY = "127.0.0.1,localhost,::1"
PROXY_VARS = ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy")
NO_PROXY_VARS = ("NO_PROXY", "no_proxy")


def redact(proxy: str | None) -> str | None:
    """Hide credentials so a proxy URL is safe to log."""
    if not proxy:
        return proxy
    parts = urlsplit(proxy if "://" in proxy else "http://" + proxy)
    if parts.username:
        netloc = parts.hostname or ""
        if parts.port:
            netloc += f":{parts.port}"
        return f"{parts.scheme}://***:***@{netloc}"
    return proxy


def validate(proxy: str) -> str:
    """Return the normalized proxy URL or raise ValueError."""
    if not isinstance(proxy, str) or not proxy.strip():
        raise ValueError("empty proxy URL")
    proxy = proxy.strip()
    parts = urlsplit(proxy if "://" in proxy else "http://" + proxy)
    if parts.scheme not in ("http", "https"):
        raise ValueError(f"proxy scheme must be http/https, got {parts.scheme!r}")
    if not parts.hostname:
        raise ValueError("proxy URL has no host")
    return proxy


def from_env() -> str | None:
    for name in PROXY_VARS:
        value = os.environ.get(name)
        if value and value.strip():
            return value.strip()
    return None


def _merge_no_proxy(explicit: str | None) -> str:
    existing = [p.strip() for p in (explicit or "").split(",") if p.strip()] if explicit else []
    if not existing:
        for name in NO_PROXY_VARS:
            if os.environ.get(name):
                existing = [p.strip() for p in os.environ[name].split(",") if p.strip()]
                break
    for host in DEFAULT_NO_PROXY.split(","):
        if host not in existing:
            existing.append(host)
    return ",".join(existing)


def apply(proxy: str | None = None, no_proxy: str | None = None) -> dict:
    """Export the proxy for this process and guarantee loopback bypasses it.

    Returns a report dict (proxy is redacted; the real value is in the env).
    """
    proxy = validate(proxy) if proxy else from_env()
    merged = _merge_no_proxy(no_proxy)
    if proxy:
        for name in PROXY_VARS:
            os.environ[name] = proxy
    for name in NO_PROXY_VARS:
        os.environ[name] = merged
    return {"applied": bool(proxy), "proxy": redact(proxy), "no_proxy": merged}


def environment(proxy: str | None = None, no_proxy: str | None = None, base=None) -> dict:
    """Return an env dict with the proxy applied (no process mutation)."""
    env = dict(base if base is not None else os.environ)
    proxy = validate(proxy) if proxy else (from_env() or None)
    merged = _merge_no_proxy(no_proxy)
    if proxy:
        for name in PROXY_VARS:
            env[name] = proxy
    for name in NO_PROXY_VARS:
        env[name] = merged
    return env