"""BBTWIN local-LLM A/B/C orchestration fabric."""

__version__ = "0.2.0"
