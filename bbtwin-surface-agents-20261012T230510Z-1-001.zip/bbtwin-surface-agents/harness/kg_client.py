"""Shared knowledge layer for the four-surface agent twin.

``CanonicalGraph`` is a read-only adapter over the BBTWIN2 methodology graph
(the common knowledge graph). ``AgentStore`` + ``SharedVectors`` are an
append-only store the agent bus owns, so the canonical model is never mutated.

Provenance rule (inherited from BBTWIN2): a mention, a filename or a version
match is not applicability. Nothing here executes a PoC or contacts a target.
"""
from __future__ import annotations

import json
import math
import sqlite3
import time
import uuid
from pathlib import Path

from .embedder import Embedder

HARNESS_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_WORKSPACE = HARNESS_ROOT / "data" / "surface-agents"
DEFAULT_METHODOLOGY = HARNESS_ROOT / "data" / "knowledge" / "methodology.sqlite3"

NODE_TYPES = (
    "advisory", "contradiction", "document", "hypothesis",
    "invariant", "program", "triz_principle",
)
EDGE_TYPES = (
    "framed_as", "asserts", "tests", "suggests",
    "mentions", "applies_to", "possible_same_program",
)


def _decode(blob):
    if isinstance(blob, (bytes, bytearray)):
        try:
            return json.loads(bytes(blob).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}
    if isinstance(blob, str):
        try:
            return json.loads(blob)
        except ValueError:
            return {}
    return {}


class CanonicalGraph:
    """Read-only view over the saved BBTWIN2 methodology graph."""

    def __init__(self, path: Path | str = DEFAULT_METHODOLOGY):
        self.path = Path(path)
        self._db = None

    @property
    def available(self) -> bool:
        return self.path.is_file()

    def _connect(self) -> sqlite3.Connection:
        if self._db is None:
            # immutable=1 guarantees the adapter cannot write the canonical model.
            self._db = sqlite3.connect(f"file:{self.path}?immutable=1", uri=True)
            self._db.row_factory = sqlite3.Row
        return self._db

    def close(self):
        if self._db is not None:
            self._db.close()
            self._db = None

    def stats(self) -> dict:
        if not self.available:
            return {"available": False, "path": str(self.path)}
        db = self._connect()
        snap = db.execute("SELECT id, created FROM snapshots LIMIT 1").fetchone()
        counts = {
            t: db.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
            for t in ("nodes", "edges", "documents", "chunks")
        }
        return {"available": True, "path": str(self.path),
                "snapshot": snap["id"] if snap else None,
                "created": snap["created"] if snap else None, **counts}

    def search(self, query: str, node_type: str | None = None,
               program: str | None = None, limit: int = 10) -> list[dict]:
        if not self.available or not query or not query.strip():
            return []
        limit = max(1, min(int(limit), 50))
        db = self._connect()
        terms = [t for t in query.replace('"', " ").split() if t]
        rows = []
        if terms:
            match = " OR ".join(f'"{t}"' for t in terms[:12])
            try:
                rows = db.execute(
                    "SELECT node_id FROM node_fts WHERE node_fts MATCH ? LIMIT ?",
                    (match, limit * 4)).fetchall()
            except sqlite3.OperationalError:
                rows = []
        ids = [r["node_id"] for r in rows]
        if ids:
            marks = ",".join("?" * len(ids))
            sql = (f"SELECT id,type,status,label,program_id,authority,source_document,"
                   f"source_digest,details FROM nodes WHERE id IN ({marks})")
            params = list(ids)
        else:
            like = f"%{query.strip()}%"
            sql = ("SELECT id,type,status,label,program_id,authority,source_document,"
                   "source_digest,details FROM nodes "
                   "WHERE label LIKE ? OR cast(details as text) LIKE ?")
            params = [like, like]
        if node_type:
            sql += " AND type = ?"
            params.append(node_type)
        if program:
            sql += " AND program_id = ?"
            params.append(program)
        sql += f" LIMIT {limit}"
        out = []
        for r in db.execute(sql, params):
            out.append({"id": r["id"], "type": r["type"], "status": r["status"],
                        "label": r["label"], "program_id": r["program_id"],
                        "authority": r["authority"],
                        "source_document": r["source_document"],
                        "source_digest": r["source_digest"],
                        "details": _decode(r["details"])})
        return out[:limit]

    def neighbors(self, node_id: str, depth: int = 1, limit: int = 40) -> dict:
        if not self.available or not node_id:
            return {"nodes": [], "edges": []}
        depth = max(1, min(int(depth), 3))
        limit = max(1, min(int(limit), 200))
        db = self._connect()
        seen = {node_id}
        frontier = {node_id}
        edges: list[dict] = []
        for _ in range(depth):
            if not frontier:
                break
            marks = ",".join("?" * len(frontier))
            rows = db.execute(
                f"SELECT id,source,target,type,status,rationale FROM edges "
                f"WHERE source IN ({marks}) OR target IN ({marks}) LIMIT ?",
                (*frontier, *frontier, limit)).fetchall()
            nxt = set()
            for r in rows:
                edges.append({"id": r["id"], "source": r["source"], "target": r["target"],
                              "type": r["type"], "status": r["status"],
                              "rationale": r["rationale"]})
                for n in (r["source"], r["target"]):
                    if n not in seen:
                        seen.add(n)
                        nxt.add(n)
            frontier = nxt
        nodes = []
        if seen:
            marks = ",".join("?" * len(seen))
            for r in db.execute(
                    f"SELECT id,type,status,label,program_id FROM nodes WHERE id IN ({marks})",
                    tuple(seen)):
                nodes.append({"id": r["id"], "type": r["type"], "status": r["status"],
                              "label": r["label"], "program_id": r["program_id"]})
        return {"nodes": nodes[:limit], "edges": edges[:limit]}


class AgentStore:
    """Append-only store the agent bus owns (never the canonical model)."""

    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS messages(
                id INTEGER PRIMARY KEY, ts TEXT, run TEXT, src TEXT, dst TEXT, type TEXT, body TEXT);
            CREATE TABLE IF NOT EXISTS claims(
                id TEXT PRIMARY KEY, ts TEXT, run TEXT, surface TEXT, attempt INTEGER,
                hypothesis TEXT, falsifier TEXT, source_refs TEXT, controls TEXT, status TEXT);
            CREATE TABLE IF NOT EXISTS handoffs(
                id TEXT PRIMARY KEY, ts TEXT, run TEXT, surface TEXT, outcome TEXT,
                done TEXT, left_over TEXT, blockers TEXT, next_hypothesis TEXT,
                artifacts TEXT, attempts_used INTEGER);
            CREATE TABLE IF NOT EXISTS vectors(
                id TEXT PRIMARY KEY, ts TEXT, run TEXT, surface TEXT, label TEXT,
                body TEXT, vector TEXT);
            CREATE TABLE IF NOT EXISTS attempts(
                run TEXT, surface TEXT, used INTEGER, max_attempts INTEGER, updated TEXT,
                PRIMARY KEY(run, surface));
            CREATE INDEX IF NOT EXISTS messages_run ON messages(run);
        """)
        # Inter-agent messaging: `dst` is a surface name, "coordinator" or "all".
        # `consumed` marks a message already taken from an agent's inbox.
        columns = {row[1] for row in self.db.execute("PRAGMA table_info(messages)")}
        if "consumed" not in columns:
            self.db.execute("ALTER TABLE messages ADD COLUMN consumed INTEGER NOT NULL DEFAULT 0")
        self.db.commit()

    def close(self):
        self.db.close()

    def message(self, run, src, dst, mtype, body):
        self.db.execute("INSERT INTO messages(ts,run,src,dst,type,body) VALUES (?,?,?,?,?,?)",
                        (time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                         run, src, dst, mtype, json.dumps(body)))
        self.db.commit()

    # -- agent <-> agent communication -------------------------------------- #
    def send(self, run, src, dst, topic, body):
        """Send a message from one agent to another ('all' broadcasts)."""
        if not src or not dst:
            raise ValueError("send requires a source and a destination")
        self.message(run, src, dst, topic, body)
        return {"from": src, "to": dst, "topic": topic}

    def broadcast(self, run, src, topic, body):
        return self.send(run, src, "all", topic, body)

    def inbox(self, run, surface, limit=20, unread_only=True, consume=True):
        """Read messages addressed to `surface` (or broadcast), oldest first."""
        limit = max(1, min(int(limit), 50))
        sql = ("SELECT id,ts,src,dst,type,body,consumed FROM messages "
               "WHERE run=? AND (dst=? OR dst='all') AND src!=?")
        if unread_only:
            sql += " AND consumed=0"
        sql += " ORDER BY id ASC LIMIT ?"
        rows = self.db.execute(sql, (run, surface, surface, limit)).fetchall()
        items = [{"id": r["id"], "ts": r["ts"], "from": r["src"], "to": r["dst"],
                  "topic": r["type"], "body": json.loads(r["body"]),
                  "consumed": bool(r["consumed"])} for r in rows]
        if consume and items:
            self.db.executemany("UPDATE messages SET consumed=1 WHERE id=?",
                                [(i["id"],) for i in items])
            self.db.commit()
        return items

    def traffic(self, run, limit=100):
        """Full message log for a run (for the coordinator's summary)."""
        return [{"id": r["id"], "ts": r["ts"], "from": r["src"], "to": r["dst"],
                 "topic": r["type"], "consumed": bool(r["consumed"])}
                for r in self.db.execute(
                    "SELECT id,ts,src,dst,type,consumed FROM messages WHERE run=? "
                    "ORDER BY id ASC LIMIT ?", (run, max(1, min(int(limit), 500))))]

    def attempts(self, run, surface, max_attempts=None):
        row = self.db.execute("SELECT used,max_attempts FROM attempts WHERE run=? AND surface=?",
                              (run, surface)).fetchone()
        if row is None:
            self.db.execute("INSERT INTO attempts(run,surface,used,max_attempts,updated) "
                            "VALUES (?,?,0,?,?)",
                            (run, surface, max_attempts or 5,
                             time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())))
            self.db.commit()
            return {"used": 0, "max": max_attempts or 5}
        return {"used": row["used"], "max": row["max_attempts"]}

    def bump_attempt(self, run, surface, max_attempts):
        cur = self.attempts(run, surface, max_attempts)
        if cur["used"] >= cur["max"]:
            return cur
        self.db.execute("UPDATE attempts SET used=used+1, updated=? WHERE run=? AND surface=?",
                        (time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), run, surface))
        self.db.commit()
        return self.attempts(run, surface)

    def claim(self, run, surface, attempt, hypothesis, falsifier, source_refs, controls, status):
        cid = f"claim-{uuid.uuid4().hex[:12]}"
        self.db.execute(
            "INSERT INTO claims(id,ts,run,surface,attempt,hypothesis,falsifier,source_refs,"
            "controls,status) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (cid, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), run, surface, attempt,
             hypothesis, falsifier, json.dumps(source_refs), json.dumps(controls), status))
        self.db.commit()
        return cid

    def handoff(self, run, surface, outcome, done, left_over, blockers, next_hypothesis,
                artifacts, attempts_used):
        hid = f"handoff-{uuid.uuid4().hex[:12]}"
        self.db.execute(
            "INSERT INTO handoffs(id,ts,run,surface,outcome,done,left_over,blockers,"
            "next_hypothesis,artifacts,attempts_used) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (hid, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), run, surface, outcome,
             json.dumps(done), json.dumps(left_over), json.dumps(blockers),
             next_hypothesis, json.dumps(artifacts), attempts_used))
        self.db.commit()
        return hid

    def add_vector(self, run, surface, label, body, vector):
        vid = f"vec-{uuid.uuid4().hex[:12]}"
        self.db.execute("INSERT INTO vectors(id,ts,run,surface,label,body,vector) "
                        "VALUES (?,?,?,?,?,?,?)",
                        (vid, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                         run, surface, label, body, json.dumps(vector)))
        self.db.commit()
        return vid

    def search_vectors(self, run, query, vector, limit=4, surface=None):
        limit = max(1, min(int(limit), 8))
        sql = "SELECT id,run,surface,label,body,vector FROM vectors"
        params: list = []
        if run:
            sql += " WHERE run=?"
            params.append(run)
            if surface:
                sql += " AND surface=?"
                params.append(surface)
        scored = []
        for r in self.db.execute(sql, params):
            stored = json.loads(r["vector"])
            if len(stored) != len(vector):
                continue
            cosine = sum(a * b for a, b in zip(vector, stored))
            if cosine > 0:
                scored.append((cosine, r))
        scored.sort(key=lambda x: -x[0])
        return [{"label": r["label"], "surface": r["surface"], "score": round(c, 4),
                 "excerpt": r["body"][:400]} for c, r in scored[:limit]]

    def latest_vector(self, run, label, surface=None):
        """Full stored body for a labelled artifact (used to hand a packet on)."""
        sql = "SELECT surface,label,body,ts FROM vectors WHERE run=? AND label=?"
        params = [run, label]
        if surface:
            sql += " AND surface=?"
            params.append(surface)
        sql += " ORDER BY ts DESC LIMIT 1"
        row = self.db.execute(sql, params).fetchone()
        return ({"surface": row["surface"], "label": row["label"],
                 "body": row["body"], "ts": row["ts"]} if row else None)

    def run_summary(self, run):
        db = self.db
        return {
            "run": run,
            "messages": db.execute("SELECT count(*) FROM messages WHERE run=?", (run,)).fetchone()[0],
            "claims": db.execute("SELECT count(*) FROM claims WHERE run=?", (run,)).fetchone()[0],
            "handoffs": db.execute("SELECT count(*) FROM handoffs WHERE run=?", (run,)).fetchone()[0],
            "vectors": db.execute("SELECT count(*) FROM vectors WHERE run=?", (run,)).fetchone()[0],
            "attempts": [dict(r) for r in db.execute(
                "SELECT surface,used,max_attempts FROM attempts WHERE run=? ORDER BY surface",
                (run,))],
            "per_surface": [dict(r) for r in db.execute(
                "SELECT surface, status, count(*) AS n FROM claims WHERE run=? "
                "GROUP BY surface,status ORDER BY surface", (run,))],
        }


class SharedVectors:
    """Hybrid lexical+vector index over agent-supplied text."""

    def __init__(self, store: AgentStore, endpoint=None, model=None):
        self.store = store
        self.embedder = Embedder(endpoint, model)

    @property
    def backend(self) -> str:
        return self.embedder.identity

    def add(self, run, surface, label, body):
        return self.store.add_vector(run, surface, label, body, self.embedder.encode(body))

    def search(self, run, query, limit=4, surface=None):
        return {"results": self.store.search_vectors(run, query, self.embedder.encode(query),
                                                     limit, surface),
                "backend": self.backend,
                "claim_boundary": "Retrieved agent text is not validation or authorization"}