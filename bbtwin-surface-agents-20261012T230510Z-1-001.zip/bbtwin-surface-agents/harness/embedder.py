"""Self-contained text embedder for the shared vector index.

Two backends:
  * ``hash-token-v1:<dim>`` — deterministic, dependency-free fallback. Not
    semantic: it is a lexical sketch, so similarity is a hint, not applicability.
  * an OpenAI-compatible ``/embeddings`` endpoint (local server or a proxy'd
    remote one). Honours ``HTTP(S)_PROXY`` from the environment; loopback
    endpoints bypass the proxy.

Written to be standalone: the analysis core stays free of any harness-wide
dependency so it can be copied, packaged and moved between machines.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import urllib.request

DIM = 256
TEXT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*|\d+")


def tokens(text: str) -> list[str]:
    """Lowercase word/number tokens, also splitting on path/dot/underscore runs."""
    flat = re.sub(r"[^\w./-]+", " ", text.lower())
    parts: list[str] = []
    for chunk in flat.split():
        parts.extend(p for p in re.split(r"[/.\-]+", chunk) if p)
    return [p for p in parts if p]


class LocalRedirect(urllib.request.HTTPRedirectHandler):
    """Refuse to leave the configured host — an embedding call must not be
    redirectable to an arbitrary location."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(newurl, code,
                                     "redirect refused by the embedding client", headers, fp)


class Embedder:
    def __init__(self, endpoint: str | None = None, model: str | None = None):
        self.endpoint = (endpoint or "").rstrip("/") or None
        self.model = model or "text-embedding"
        self.identity = (f"local-dense:{self.endpoint}:{self.model}"
                         if self.endpoint else f"hash-token-v1:{DIM}")

    def encode(self, text: str) -> list[float]:
        if self.endpoint:
            vector = self._remote(text)
        else:
            vector = self._hash(text)
        norm = math.sqrt(sum(v * v for v in vector)) or 1.0
        return [v / norm for v in vector]

    def _remote(self, text: str) -> list[float]:
        # ProxyHandler() with no args reads HTTP(S)_PROXY/NO_PROXY from the env;
        # loopback endpoints stay direct because NO_PROXY includes them.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler(), LocalRedirect())
        request = urllib.request.Request(
            self.endpoint + "/embeddings",
            data=json.dumps({"model": self.model, "input": text}).encode(),
            headers={"Content-Type": "application/json"})
        with opener.open(request, timeout=60) as response:
            vector = json.load(response)["data"][0]["embedding"]
        if (not isinstance(vector, list) or not 1 <= len(vector) <= 16384
                or any(isinstance(v, bool) or not isinstance(v, (int, float))
                       or not math.isfinite(v) for v in vector)):
            raise ValueError("invalid embedding response")
        return vector

    @staticmethod
    def _hash(text: str) -> list[float]:
        vector = [0.0] * DIM
        for term in tokens(text):
            digest = hashlib.sha256(term.encode()).digest()
            vector[int.from_bytes(digest[:2], "big") % DIM] += 1 if digest[2] % 2 else -1
        return vector