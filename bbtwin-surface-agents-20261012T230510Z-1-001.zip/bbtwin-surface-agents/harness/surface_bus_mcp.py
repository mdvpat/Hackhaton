"""MCP server exposing the four-surface agent bus to the qwenccrx6 frontend.

Wraps one in-process ``SurfaceAgent`` per surface (AD/WEB/API/OSS) behind a
single MCP stdio server, so the Free Code frontend can probe, query the shared
knowledge graph, and drive bounded claims/handoffs with ordinary language.

Attach with:

    qwenccrx6 --mcp-config ./harness/surface_bus_mcp.json ...

Local, read-only probes only: no target traffic, no PoC execution, no submission.
"""
from __future__ import annotations

import argparse
import contextlib
import json
import sys
from pathlib import Path

from .agent_bus import run_demo
from .kg_client import HARNESS_ROOT
from .surface_agent import DEFAULT_CONFIG, SurfaceAgent, load_config


def _tool(name, description, properties=None, required=(), readonly=True):
    return {"name": name, "description": description,
            "inputSchema": {"type": "object", "properties": properties or {},
                            "required": list(required), "additionalProperties": False},
            "annotations": {"readOnlyHint": readonly, "destructiveHint": False,
                            "openWorldHint": False}}


SURFACE_ENUM = ["AD", "WEB", "API", "OSS"]

TOOLS = [
    _tool("surface_bus_status", "Per-surface attempt ledger plus shared knowledge-graph and vector state."),
    _tool("surface_probe", "Run one surface's bounded read-only local probe.",
          {"surface": {"type": "string", "enum": SURFACE_ENUM}}, ("surface",)),
    _tool("surface_query_kg", "Search the shared BBTWIN2 knowledge graph.",
          {"query": {"type": "string", "maxLength": 500}, "node_type": {"type": "string"},
           "limit": {"type": "integer"}}, ("query",)),
    _tool("surface_query_vectors", "Search the shared hybrid vector index.",
          {"query": {"type": "string", "maxLength": 500}, "limit": {"type": "integer"}},
          ("query",)),
    _tool("surface_capabilities",
          "Return the AD capability packet (principal -> capability -> crown-jewel target) "
          "to hand to the other surfaces. Any surface may request it.",
          {"surface": {"type": "string", "enum": SURFACE_ENUM}}, ()),
    _tool("surface_send", "Send a message between agents ('coordinator' or a surface name; 'all' broadcasts).",
          {"from_surface": {"type": "string"}, "to": {"type": "string"},
           "topic": {"type": "string", "maxLength": 120},
           "body": {"type": "string", "maxLength": 4000}}, ("to", "topic", "body"), False),
    _tool("surface_inbox", "Read a surface agent's unread messages (broadcasts included).",
          {"surface": {"type": "string", "enum": SURFACE_ENUM},
           "limit": {"type": "integer"}}, ("surface",)),
    _tool("surface_traffic", "Show the inter-agent message log for this run.",
          {"limit": {"type": "integer"}}),
    _tool("surface_claim", "Record one hypothesis (needs falsifier + source_refs). "
                           "Consumes one of the 5 attempts.",
          {"surface": {"type": "string", "enum": SURFACE_ENUM},
           "hypothesis": {"type": "string", "maxLength": 1200},
           "falsifier": {"type": "string", "maxLength": 600},
           "source_refs": {"type": "array", "items": {"type": "string"}},
           "controls": {"type": "array", "items": {"type": "string"}},
           "status": {"type": "string", "enum": ["supported", "hold", "reject", "unresolved"]}},
          ("surface", "hypothesis", "falsifier", "source_refs"), False),
    _tool("surface_handoff", "Report back: what was done and what is left. Required once the budget is exhausted.",
          {"surface": {"type": "string", "enum": SURFACE_ENUM},
           "outcome": {"type": "string", "enum": ["resolved", "unresolved", "blocked"]},
           "done": {"type": "array", "items": {"type": "string"}},
           "left": {"type": "array", "items": {"type": "string"}},
           "blockers": {"type": "array", "items": {"type": "string"}},
           "next_hypothesis": {"type": "string"}},
          ("surface", "outcome", "done", "left"), False),
    _tool("surface_run", "Run the coordinator over all four surfaces (probe -> claims -> handoff) and write a run bundle.",
          {"run": {"type": "string"}}, ("run",), False),
    _tool("surface_attempts", "Read the attempt ledger for the active run.",
          {"run": {"type": "string"}}),
]


class SurfaceBusServer:
    def __init__(self, run="mcp-session", config_path=DEFAULT_CONFIG, workspace=None):
        self.config_path = Path(config_path)
        self.config = load_config(self.config_path)
        if workspace:
            self.config["workspace"] = str(workspace)
        self.workspace = Path(self.config["workspace"])
        self.run = run
        self._agents: dict[str, SurfaceAgent] = {}

    def agent(self, surface):
        if surface not in self.config["surfaces"]:
            raise ValueError(f"unknown surface {surface!r}")
        if surface not in self._agents:
            self._agents[surface] = SurfaceAgent(surface, self.config, self.run)
        return self._agents[surface]

    def close(self):
        for a in self._agents.values():
            a.close()
        self._agents.clear()

    def _status(self):
        return {"run": self.run, "workspace": str(self.workspace),
                "surfaces": {s: self.agent(s).status() for s in self.config["surfaces"]}}

    def call(self, name, args):
        if name == "surface_bus_status":
            return self._status()
        if name == "surface_probe":
            return self.agent(args["surface"]).call("agent_probe", {})
        if name == "surface_capabilities":
            return self.agent(args.get("surface") or "AD").call("agent_capabilities", {})
        if name == "surface_send":
            src = str(args.pop("from_surface", None) or "coordinator").strip()
            return self.agent("AD").store.send(self.run, src, str(args["to"]).strip(),
                                              str(args.get("topic") or "note"), args.get("body"))
        if name == "surface_inbox":
            surface = args["surface"]
            return {"surface": surface,
                    "messages": self.agent(surface).store.inbox(self.run, surface,
                                                                args.get("limit", 20))}
        if name == "surface_traffic":
            return {"run": self.run,
                    "log": self.agent("AD").store.traffic(self.run, args.get("limit", 100))}
        if name == "surface_query_kg":
            return self.agent("AD").call("agent_query_kg", args)
        if name == "surface_query_vectors":
            return self.agent("AD").call("agent_query_vectors", args)
        if name == "surface_claim":
            surface = args.pop("surface")
            return self.agent(surface).call("agent_claim", args)
        if name == "surface_handoff":
            surface = args.pop("surface")
            return self.agent(surface).call("agent_handoff", args)
        if name == "surface_attempts":
            run = args.get("run") or self.run
            store = self.agent("AD").store
            return {"run": run, "attempts": [{"surface": s, **store.attempts(run, s,
                    self.config.get("max_attempts", 5))} for s in self.config["surfaces"]]}
        if name == "surface_run":
            summary, run_dir = run_demo(args["run"], self.config_path, self.workspace)
            return {"run": args["run"], "summary": str(run_dir / "run-summary.json"),
                    "ledger": summary["attempts"], "outcomes": summary["outcomes"]}
        raise ValueError("unknown surface-bus tool")

    def dispatch(self, request):
        if not isinstance(request, dict):
            raise ValueError("JSON-RPC object required")
        method, ident = request.get("method"), request.get("id")
        if ident is None:
            return None
        try:
            if method == "initialize":
                return _ok(ident, {"protocolVersion": "2024-11-05",
                                   "capabilities": {"tools": {}},
                                   "serverInfo": {"name": "surface-bus", "version": "1.0.0"},
                                   "instructions": "Four read-only surface agents sharing one "
                                                   "knowledge graph; 5 attempts then handoff."})
            if method == "ping":
                return _ok(ident, {})
            if method == "tools/list":
                return _ok(ident, {"tools": TOOLS})
            if method == "tools/call":
                p = request["params"]
                try:
                    with contextlib.redirect_stdout(sys.stderr):
                        value = self.call(p["name"], dict(p.get("arguments", {})))
                    return _ok(ident, {"content": [{"type": "text", "text": json.dumps(value)}]})
                except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
                    return _ok(ident, {"isError": True,
                                       "content": [{"type": "text", "text": str(exc)}]})
            return {"jsonrpc": "2.0", "id": ident,
                    "error": {"code": -32601, "message": "Unsupported MCP method"}}
        except (ValueError, KeyError, TypeError) as exc:
            return {"jsonrpc": "2.0", "id": ident, "error": {"code": -32602, "message": str(exc)}}


def _ok(ident, result):
    return {"jsonrpc": "2.0", "id": ident, "result": result}


def main(argv=None):
    ap = argparse.ArgumentParser(description="MCP server for the four-surface agent bus")
    ap.add_argument("--run", default="mcp-session")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--workspace")
    ap.add_argument("--call", help="one-shot: NAME[:json-args]")
    args = ap.parse_args(argv)
    server = SurfaceBusServer(args.run, args.config, args.workspace)
    try:
        if args.call:
            name, _, raw = args.call.partition(":")
            extra = json.loads(raw) if raw else {}
            print(json.dumps(server.call(name, extra), indent=2))
            return 0
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                reply = server.dispatch(json.loads(line))
            except ValueError:
                reply = {"jsonrpc": "2.0", "id": None,
                         "error": {"code": -32700, "message": "Invalid JSON"}}
            if reply is not None:
                print(json.dumps(reply), flush=True)
    finally:
        server.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())