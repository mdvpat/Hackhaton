"""Coordinator for the four-surface agent twin.

Spawns one ``surface_agent`` MCP server per surface over stdio, drives them
through probe -> shared-KG/vector queries -> bounded claims -> handoff, and
writes a run summary. The bus is read-only against targets: agents only run
local probes over owned/synthetic inputs.

    python3 -m harness.agent_bus --run demo-1
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from .kg_client import HARNESS_ROOT, AgentStore, CanonicalGraph
from .surface_agent import DEFAULT_CONFIG, load_config

RUNS_DIR = HARNESS_ROOT / "data" / "surface-agents" / "runs"

# Illustrative demo hypotheses. They are labels, not findings: every claim the
# bus records is tagged status=unresolved except where a surface is scripted to
# resolve, and none of them is a validated vulnerability.
DEMO_HYPOTHESES = {
    "AD": [
        ("A short ACL path reaches a high-value group from an unprivileged principal.",
         "Run the path finder with --target-mode all; if no path is found the hypothesis is false.",
         ["data/surface-agents/ad/company1", "normalized-graph.json"], "supported"),
        ("Delegation edges bypass the group-membership path.",
         "Grep the canonical graph for ALLOWEDDELEGATION edges; none found => false.", [], "unresolved"),
    ],
    "WEB": [
        ("A JS bundle leaks an authenticated API base URL.",
         "Re-scan with the bundle removed; endpoints must disappear.", ["bundle.js"], "unresolved"),
        ("An admin route is reachable without auth.",
         "Probe the route with no credentials in an owned lab.", [], "unresolved"),
        ("A source map reconstructs server source.",
         "Fetch the .map and look for server paths.", [], "unresolved"),
        ("A token is hardcoded in the bundle.",
         "Regex for token literals; empty => false.", [], "unresolved"),
        ("A cache header enables web cache deception.",
         "Replay with a static extension; content-type must change.", [], "unresolved"),
    ],
    "API": [
        ("A route lacks a security block.",
         "Count routes whose op.security and global security are both absent.", ["openapi.json"], "hold"),
        ("An IDOR lets one tenant read another.",
         "Swap the object id in an owned lab; a 403/404 falsifies it.", [], "unresolved"),
    ],
    "OSS": [
        ("A command-exec sink is reachable from user input.",
         "Trace the sink to a user-controlled parameter; unreachable => false.", ["app.py"], "unresolved"),
        ("An unsafe deserialization sink exists.",
         "Locate a pickle/yaml sink on untrusted bytes.", [], "unresolved"),
        ("A secret literal is committed.",
         "Scan history for key-shaped strings.", [], "unresolved"),
        ("An eval sink is reachable.",
         "Trace eval to untrusted input.", [], "unresolved"),
        ("A path-traversal sink is reachable.",
         "Trace a file open to a request parameter.", [], "unresolved"),
    ],
}

KG_QUERIES = {"AD": "authorization", "WEB": "SSRF", "API": "RBAC",
              "OSS": "command execution"}


class MCPClient:
    """Minimal line-delimited JSON-RPC client over a subprocess stdio pipe."""

    def __init__(self, surface, run, config_path, cwd):
        self.surface = surface
        self._id = 0
        self.proc = subprocess.Popen(
            [sys.executable, "-m", "harness.surface_agent", "--surface", surface,
             "--run", run, "--config", str(config_path), "--serve-stdio"],
            cwd=str(cwd), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True)
        self.rpc("initialize", {"protocolVersion": "2024-11-05",
                                "clientInfo": {"name": "agent_bus", "version": "1.0.0"}})

    def rpc(self, method, params=None):
        self._id += 1
        req = {"jsonrpc": "2.0", "id": self._id, "method": method}
        if params is not None:
            req["params"] = params
        self.proc.stdin.write(json.dumps(req) + "\n")
        self.proc.stdin.flush()
        line = self.proc.stdout.readline()
        if not line:
            err = self.proc.stderr.read()[-2000:] if self.proc.stderr else ""
            raise RuntimeError(f"{self.surface}: agent closed ({err})")
        reply = json.loads(line)
        if "error" in reply:
            raise RuntimeError(f"{self.surface}: {reply['error']}")
        return reply["result"]

    def call(self, name, args=None):
        res = self.rpc("tools/call", {"name": name, "arguments": args or {}})
        text = res["content"][0]["text"]
        if res.get("isError"):
            raise RuntimeError(text)
        return json.loads(text)

    def close(self):
        for stream in (self.proc.stdin,):
            try:
                stream.close()
            except OSError:
                pass
        try:
            self.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.proc.terminate()


def drive(client, surface, log):
    probe = client.call("agent_probe")
    log.append({"surface": surface, "step": "probe",
                "summary": {k: probe[k] for k in list(probe)[:4]}})
    client.call("agent_query_kg", {"query": KG_QUERIES.get(surface, surface), "limit": 5})
    client.call("agent_query_vectors", {"query": f"{surface} attack surface", "limit": 3})

    # -- inter-agent communication ----------------------------------------- #
    # 1. every surface broadcasts its probe result so the others can use it
    client.call("agent_send", {"to": "all", "topic": f"{surface}:probe-ready",
                              "body": {"surface": surface,
                                       "keys": [k for k in probe][:6]}})
    # 2. AD is the capability authority: compute and hand the packet to everyone
    if surface == "AD":
        packet = client.call("agent_capabilities")
        client.call("agent_send", {
            "to": "all", "topic": "AD:capabilities",
            "body": {"schema": packet["schema"],
                     "identities_with_direct_control": packet["identities_with_direct_control"],
                     "high_value_edges": packet["totals"]["high_value_capability_edges"]}})
        log.append({"surface": surface, "step": "broadcast",
                    "topic": "AD:capabilities",
                    "identities": len(packet["identities_with_direct_control"])})
    # 3. drain this surface's inbox (messages from earlier surfaces)
    inbox = client.call("agent_inbox", {})
    log.append({"surface": surface, "step": "inbox", "received": len(inbox["messages"]),
                "topics": [m["topic"] for m in inbox["messages"]]})

    resolved = False
    for hypothesis, falsifier, refs, status in DEMO_HYPOTHESES.get(surface, []):
        if resolved:
            break
        try:
            out = client.call("agent_claim", {
                "hypothesis": hypothesis, "falsifier": falsifier,
                "source_refs": refs or [f"probe:{surface}"],
                "controls": ["negative-control"], "status": status})
        except RuntimeError as exc:
            log.append({"surface": surface, "step": "claim_refused", "reason": str(exc)})
            break
        log.append({"surface": surface, "step": "claim",
                    "attempt": out["attempt"], "remaining": out["remaining"],
                    "status": out["status"]})
        if status == "supported":
            resolved = True

    client.call("agent_publish", {
        "label": f"{surface}:summary",
        "body": json.dumps({"surface": surface, "probe": probe, "resolved": resolved})[:3900]})

    if resolved:
        return {"surface": surface, "outcome": "resolved"}, log
    hand = client.call("agent_handoff", {
        "outcome": "unresolved",
        "done": [f"local {surface} probe completed",
                 f"{len(DEMO_HYPOTHESES.get(surface, []))} candidate hypotheses evaluated"],
        "left": [h for h, *_ in DEMO_HYPOTHESES.get(surface, [])][1:],
        "blockers": ["attempt budget exhausted (5)", "no local negative-control discriminator"],
        "next_hypothesis": "chain the strongest candidate with a second surface"})
    log.append({"surface": surface, "step": "handoff",
                "outcome": hand["outcome"], "attempts_used": hand["attempts_used"]})
    return {"surface": surface, "outcome": "unresolved",
            "handoff": hand, "attempts_used": hand["attempts_used"]}, log


def run_demo(run, config_path, workspace):
    config = load_config(config_path)
    config["workspace"] = str(workspace)
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    log: list = []
    results = []
    clients = {}
    try:
        for surface in config["surfaces"]:
            clients[surface] = MCPClient(surface, run, config_path, HARNESS_ROOT)
        for surface, client in clients.items():
            outcome, log = drive(client, surface, log)
            results.append(outcome)
    finally:
        for client in clients.values():
            client.close()

    store = AgentStore(workspace / "agent_kg.sqlite3")
    summary = store.run_summary(run)
    graph = CanonicalGraph(config.get("methodology_graph") or CanonicalGraph().path)
    summary["knowledge_graph"] = graph.stats()
    graph.close()
    summary["outcomes"] = results
    store.message(run, "coordinator", "all", "run-complete", summary)
    store.close()

    run_dir = workspace / "runs" / run
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "bus-log.jsonl").write_text(
        "\n".join(json.dumps(x) for x in log) + "\n", encoding="utf-8")
    (run_dir / "run-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (run_dir / "SURFACE-RUN.md").write_text(render_markdown(run, summary, log), encoding="utf-8")
    return summary, run_dir


def render_markdown(run, summary, log):
    lines = [f"# Surface-agent bus run `{run}`", "",
             f"- Messages: {summary['messages']}  |  Claims: {summary['claims']}  |  "
             f"Handoffs: {summary['handoffs']}  |  Vectors: {summary['vectors']}", ""]
    lines += ["## Attempt ledger", "", "| Surface | Used | Max |", "|---|---:|---:|"]
    for a in summary["attempts"]:
        lines.append(f"| {a['surface']} | {a['used']} | {a['max_attempts']} |")
    lines += ["", "## Outcomes", "", "| Surface | Outcome |", "|---|---|"]
    for o in summary["outcomes"]:
        lines.append(f"| {o['surface']} | {o['outcome']} |")
    lines += ["", "## Handoffs (what was done / what is left)", ""]
    for entry in log:
        if entry["step"] == "handoff":
            lines.append(f"- **{entry['surface']}** — {entry['outcome']} "
                         f"after {entry['attempts_used']} attempts")
    lines += ["", "Read-only local run; hypotheses are illustrative labels, not validated "
              "findings. See `bus-log.jsonl` for the full message trace.", ""]
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Four-surface agent coordinator")
    ap.add_argument("--run", default="demo-1")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--workspace", default=str(HARNESS_ROOT / "data" / "surface-agents"))
    args = ap.parse_args(argv)
    summary, run_dir = run_demo(args.run, Path(args.config), Path(args.workspace))
    print(json.dumps({"run": args.run, "summary": str(run_dir / "run-summary.json"),
                      "ledger": summary["attempts"], "outcomes": summary["outcomes"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())