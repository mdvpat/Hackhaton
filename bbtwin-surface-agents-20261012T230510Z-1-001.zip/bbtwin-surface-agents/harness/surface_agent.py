"""One MCP surface agent for the four-surface twin.

Each agent is a line-delimited JSON-RPC MCP server over stdio (same framing as
``qwenccrx6_mcp.py``). It owns one surface (AD / Web / API / OSS), holds a
5-attempt ledger, and exposes read-only local probes plus shared-KG/vector
queries. It never contacts a target, executes an imported PoC, or submits.

Run standalone:
    python3 -m harness.surface_agent --surface AD --run demo-1 --serve-stdio
    python3 -m harness.surface_agent --surface AD --run demo-1 --probe
    python3 -m harness.surface_agent --surface AD --canonicalize <bh_dir> --out <file>
"""
from __future__ import annotations

import argparse
import contextlib
import json
import re
import subprocess
import sys
from pathlib import Path

from .kg_client import (HARNESS_ROOT, AgentStore, CanonicalGraph, SharedVectors)

CYBERTWIN = Path(__file__).resolve().parent.parent.parent / "cybertwin.ai"
DEFAULT_FINDER = CYBERTWIN / "tools" / "bloodhound_attack_path_finder.py"
DEFAULT_CONFIG = HARNESS_ROOT / "harness" / "surface_agents.json"

MAX_SCAN_BYTES = 400_000
MAX_SCAN_FILES = 200

BH_FILES = {"users": "USER", "computers": "COMPUTER", "groups": "GROUP",
            "ous": "OU", "containers": "CONTAINER", "domains": "DOMAIN", "gpos": "GPO"}

KEEP_RIGHTS = {
    "GENERICALL", "GENERICWRITE", "WRITEDACL", "WRITEOWNER", "OWNS", "ADDMEMBER",
    "ADDSELF", "FORCECHANGEPASSWORD", "ALLOWEDELEGATION", "UNCONSTRAINEDDELEGATION",
    "CONSTRAINEDDELEGATION", "READLAPSPASSWORD", "DCSYNC", "ALLOWEDTOACT",
    "CANRDP", "CANPSREMOTE", "EXECUTEDCOM", "ADMINTO", "HASSESSION", "MEMBEROF",
    "OWNER", "WRITEALLPROPERTIES", "WRITEPROPERTIES",
}

WEB_ENDPOINT_RE = re.compile(
    r"""(?:["'`])((?:https?://[^"'`\s]+)|(?:/[A-Za-z0-9_\-./{}:]{3,120}))(?:["'`])""")
API_METHODS = ("get", "post", "put", "patch", "delete", "head", "options", "trace")
OSS_PATTERNS = [
    ("command_exec", re.compile(r"\b(?:os\.system|subprocess\.(?:run|call|Popen|check_output)|Runtime\.getRuntime|child_process\.(?:exec|spawn))\b")),
    ("dynamic_eval", re.compile(r"\b(?:eval|exec)\s*\(")),
    ("unsafe_deser", re.compile(r"\b(?:pickle\.loads|yaml\.load\s*\(|marshal\.loads|ObjectInputStream|BinaryFormatter)\b")),
    ("ssrf_fetch", re.compile(r"\b(?:requests\.get|urllib\.request\.urlopen|axios\.(?:get|post)|fetch\s*\()")),
    ("xss_sink", re.compile(r"\b(?:innerHTML|dangerouslySetInnerHTML|document\.write|v-html)\b")),
    ("path_sink", re.compile(r"\b(?:open\s*\(|readFile|sendFile|File\s*\()\s*[^)]*\b(?:req|input|params|query)")),
    ("weak_crypto", re.compile(r"\b(?:md5|sha1|DES|RC4|ECB)\b", re.IGNORECASE)),
    ("secret_literal", re.compile(r"""(?:api[_-]?key|secret|password|token)\s*[:=]\s*["'][^"']{6,}["']""", re.IGNORECASE)),
]


# --------------------------------------------------------------------------- #
# BloodHound v5 canonicalization
# --------------------------------------------------------------------------- #
def _rights_for_object(record):
    """Return {principal: {RIGHT,...}} for one SharpHound v5 object."""
    rights: dict[str, set] = {}
    for ace in record.get("Aces") or []:
        if not isinstance(ace, dict):
            continue
        if str(ace.get("Type", "Allow")).upper() not in {"ALLOW", "ALLOWED", "ALLOWING", ""}:
            continue
        principal = ace.get("PrincipalSID") or ace.get("PrincipalId")
        raw = str(ace.get("RightName") or "").upper().replace(" ", "")
        if not principal or principal in ("S-1-0-0", "") or not raw:
            continue
        rights.setdefault(principal, set()).add(raw)
    return rights


def _ident(value):
    """Coerce a SharpHound v5 principal reference (str or object) to an id."""
    if isinstance(value, str):
        return value.strip() or None
    if isinstance(value, dict):
        for key in ("ObjectIdentifier", "ObjectId", "ObjectID", "Sid", "SID",
                    "UserSID", "ComputerSID", "objectid"):
            got = value.get(key)
            if isinstance(got, str) and got.strip():
                return got.strip()
    return None


def canonicalize_bloodhound(data_dir: Path) -> dict:
    """SharpHound v5 -> normalized {nodes,edges} graph the finder can consume."""
    nodes: dict[str, dict] = {}
    edges: list[dict] = []
    pending_rights: dict[tuple, set] = {}

    def add_node(nid, name=None, ntype="UNKNOWN", highvalue=False, domain=None):
        nid = _ident(nid)
        if not nid:
            return
        full = name or nid
        if domain and name and "@" not in name:
            full = f"{name}@{domain}"
        nodes.setdefault(nid, {"id": nid, "name": full, "type": ntype,
                               "highvalue": bool(highvalue)})

    def add_edge(src, dst, etype):
        src, dst = _ident(src), _ident(dst)
        if src and dst and src != dst:
            edges.append({"src": src, "dst": dst, "type": etype})

    for path in sorted(Path(data_dir).glob("*.json")):
        try:
            doc = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        except ValueError:
            continue
        ftype = (doc.get("meta") or {}).get("type")
        ntype = BH_FILES.get(ftype, "UNKNOWN")
        for rec in doc.get("data") or []:
            if not isinstance(rec, dict):
                continue
            oid = rec.get("ObjectIdentifier")
            props = rec.get("Properties") or {}
            add_node(oid, props.get("name") or props.get("samaccountname"),
                     ntype, props.get("highvalue"), props.get("domain"))
            # group membership (v5 puts Members on the group object)
            for m in rec.get("Members") or []:
                add_edge(_ident(m), oid, "MEMBEROF")
            # primary group linkage on user/computer objects
            pg = rec.get("PrimaryGroupSID")
            if pg:
                add_edge(oid, pg, "MEMBEROF")
            # ACL rights principal -> object
            for principal, rights in _rights_for_object(rec).items():
                pending_rights.setdefault((principal, oid), set()).update(rights)
            # local admin / RDP / PSRemote / sessions on computers
            for key, etype in (("LocalAdmins", "ADMINTO"), ("RemoteDesktopUsers", "CANRDP"),
                               ("PSRemoteUsers", "CANPSREMOTE"), ("DcomUsers", "EXECUTEDCOM")):
                block = rec.get(key)
                if isinstance(block, dict):
                    for sid in block.get("Results") or []:
                        add_edge(sid, oid, etype)
            for key, etype in (("Sessions", "HASSESSION"), ("PrivilegedSessions", "HASSESSION"),
                               ("RegistrySessions", "HASSESSION")):
                block = rec.get(key)
                if isinstance(block, dict):
                    for sid in block.get("Results") or []:
                        add_edge(sid, oid, etype)
            for key, etype in (("AllowedToDelegate", "ALLOWEDDELEGATION"),
                               ("AllowedToAct", "ALLOWEDTOACT")):
                for sid in rec.get(key) or []:
                    add_edge(oid, sid, etype)

    for (principal, oid), rights in pending_rights.items():
        if {"GETCHANGES", "GETCHANGESALL"} <= rights:
            add_edge(principal, oid, "DCSYNC")
        for right in rights:
            if right in ("GETCHANGES", "GETCHANGESALL"):
                continue
            if right in KEEP_RIGHTS:
                add_edge(principal, oid, right)
    return {"nodes": sorted(nodes.values(), key=lambda n: n["id"]), "edges": edges}


# --------------------------------------------------------------------------- #
# Capability ledger (what one principal can do to another)
# --------------------------------------------------------------------------- #
# Rights that transfer control of another object, plus direct access edges.
CAPABILITY_RIGHTS = {
    "GENERICALL", "GENERICWRITE", "WRITEDACL", "WRITEOWNER", "OWNS", "ADDMEMBER",
    "ADDSELF", "FORCECHANGEPASSWORD", "ALLOWEDDELEGATION", "UNCONSTRAINEDDELEGATION",
    "CONSTRAINEDDELEGATION", "READLAPSPASSWORD", "DCSYNC", "ALLOWEDTOACT",
}
ACCESS_RIGHTS = {"ADMINTO", "CANRDP", "CANPSREMOTE", "EXECUTEDCOM"}
SESSION_RIGHT = "HASSESSION"
HIGH_VALUE_PATTERNS = [
    r"DOMAIN ADMINS@", r"ENTERPRISE ADMINS@", r"SCHEMA ADMINS@",
    r"BUILTIN\\ADMINISTRATORS", r"TIER\s*0", r"PRIVILEGED", r"ENTERPRISE KEY", r"KRBTGT",
]


def is_high_value(name: str, node: dict | None = None) -> bool:
    if node and node.get("highvalue"):
        return True
    upper = (name or "").upper()
    return any(re.search(p, upper) for p in HIGH_VALUE_PATTERNS)


def _membership_closure(seed: str, memberof: dict) -> set:
    seen, stack = set(), list(memberof.get(seed, ()))
    while stack:
        group = stack.pop()
        if group in seen:
            continue
        seen.add(group)
        stack.extend(memberof.get(group, ()))
    return seen


def capability_ledger(graph: dict, limit: int = 200) -> dict:
    """Turn the canonical graph into (principal -> capability -> target) rows.

    Direct capabilities come from ACL/access edges. Inherited capabilities are
    what a principal gains through transitive group membership, which is the
    form other surfaces need when they ask "can this identity reach X?".
    """
    nodes = {n["id"]: n for n in graph["nodes"]}

    def node(nid):
        return nodes.get(nid, {"id": nid, "name": nid, "type": "UNKNOWN", "highvalue": False})

    memberof: dict[str, set] = {}
    direct: list[dict] = []
    for edge in graph["edges"]:
        etype, src, dst = edge["type"], edge["src"], edge["dst"]
        if etype == "MEMBEROF":
            memberof.setdefault(src, set()).add(dst)
            continue
        if etype not in CAPABILITY_RIGHTS and etype not in ACCESS_RIGHTS \
                and etype != SESSION_RIGHT:
            continue
        frm, to = node(src), node(dst)
        direct.append({
            "capability": etype,
            "from": {"name": frm["name"], "type": frm["type"], "id": frm["id"]},
            "to": {"name": to["name"], "type": to["type"], "id": to["id"]},
            "target_high_value": is_high_value(to["name"], to),
            "kind": "acl" if etype in CAPABILITY_RIGHTS else
                    "access" if etype in ACCESS_RIGHTS else "session",
        })

    granted_to: dict[str, list] = {}
    for cap in direct:
        granted_to.setdefault(cap["to"]["id"], []).append(cap)

    inherited: list[dict] = []
    for principal in list(memberof):
        for group in _membership_closure(principal, memberof):
            for cap in granted_to.get(group, []):
                inherited.append({
                    "capability": cap["capability"],
                    "from": node(principal)["name"],
                    "via_group": node(group)["name"],
                    "to": cap["to"]["name"],
                    "target_high_value": cap["target_high_value"],
                    "kind": "inherited-" + cap["kind"],
                })
                if len(inherited) >= limit * 4:
                    break
            if len(inherited) >= limit * 4:
                break

    # Who can reach a crown-jewel target, directly or through a group?
    reach: dict[str, set] = {}
    for cap in direct:
        if cap["target_high_value"]:
            reach.setdefault(cap["to"]["name"], set()).add(cap["from"]["name"])
    for row in inherited:
        if row["target_high_value"]:
            reach.setdefault(row["to"], set()).add(row["from"])

    by_type: dict[str, int] = {}
    for cap in direct:
        by_type[cap["capability"]] = by_type.get(cap["capability"], 0) + 1
    high_value_direct = [c for c in direct if c["target_high_value"]]
    high_value_direct.sort(key=lambda c: c["capability"])

    return {
        "schema": "bbtwin.capability-ledger/v1",
        "summary": {
            "principals_and_groups": len(graph["nodes"]),
            "edges": len(graph["edges"]),
            "direct_capabilities": len(direct),
            "inherited_capabilities": len(inherited),
            "capabilities_by_type": dict(sorted(by_type.items(), key=lambda kv: -kv[1])),
            "high_value_capability_edges": len(high_value_direct),
            "principals_reaching_high_value": sorted(
                {who for names in reach.values() for who in names}),
        },
        "reachable_high_value_targets": {t: sorted(w) for t, w in sorted(reach.items())},
        "direct_capabilities": direct,
        "inherited_capabilities": inherited[:limit * 4],
        "capability_boundary": "Static AD ACL/access edges from the supplied export. "
                               "A capability is not an executed action; no path is run.",
    }


# --------------------------------------------------------------------------- #
# Local, read-only probes
# --------------------------------------------------------------------------- #
def probe_ad(input_path: Path, out_dir: Path, finder=DEFAULT_FINDER, args=None) -> dict:
    args = args or {}
    graph = canonicalize_bloodhound(input_path)
    out_dir.mkdir(parents=True, exist_ok=True)
    graph_file = out_dir / "normalized-graph.json"
    graph_file.write_text(json.dumps(graph, indent=1), encoding="utf-8")
    # The finder is an optional external tool. The capability ledger below does
    # not need it, so a host without cybertwin.ai (e.g. Leonardo) still works.
    finder_path = Path(finder)
    if finder_path.is_file():
        cmd = [sys.executable, str(finder_path), str(graph_file),
               "--target-mode", str(args.get("target_mode", "high-value")),
               "--path-mode", str(args.get("path_mode", "shortest")),
               "--max-depth", str(args.get("max_depth", 8)),
               "--top", "20", "--outdir", str(out_dir / "finder-out")]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        finder_rc, finder_note = proc.returncode, None
    else:
        finder_rc, finder_note = None, f"path finder not present at {finder_path}; " \
                                       "capability ledger computed without path enumeration"
    report_file = out_dir / "finder-out" / "bloodhound_attack_paths.json"
    report = json.loads(report_file.read_text()) if report_file.is_file() else {}
    ledger = capability_ledger(graph)
    (out_dir / "capability-ledger.json").write_text(json.dumps(ledger, indent=1), encoding="utf-8")
    return {
        "dataset": str(input_path),
        "canonical": {"nodes": len(graph["nodes"]), "edges": len(graph["edges"]),
                      "types": _count(graph["nodes"], "type")},
        "finder_rc": finder_rc,
        "finder_note": finder_note,
        "targets": [t["name"] for t in report.get("targets", [])][:15],
        "paths_found": report.get("paths_found"),
        "capabilities": ledger["summary"],
        "capability_ledger": str(out_dir / "capability-ledger.json"),
        "ranked_candidates": [
            {"name": c["name"], "type": c["type"], "score": c["score"],
             "paths_referencing": c["paths_referencing"]}
            for c in report.get("ranked_candidates", [])[:10]],
        "graph_file": str(graph_file),
        "boundary": "Local synthetic/owned export only; graph paths are not executed.",
    }


def probe_web(input_path: Path, out_dir: Path, finder=None, args=None) -> dict:
    endpoints, hosts, files = set(), set(), 0
    root = Path(input_path)
    candidates = ([root] if root.is_file() else
                  [p for p in sorted(root.rglob("*"))
                   if p.is_file() and p.suffix.lower() in
                   {".js", ".mjs", ".map", ".html", ".htm", ".json", ".txt"}])
    for p in candidates[:MAX_SCAN_FILES]:
        try:
            if p.stat().st_size > MAX_SCAN_BYTES:
                continue
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        files += 1
        for m in WEB_ENDPOINT_RE.finditer(text):
            v = m.group(1)
            if v.startswith("http"):
                hosts.add(v)
            elif any(k in v.lower() for k in ("/api", "/v1", "/v2", "/graphql", "/admin",
                                              "/auth", "/users", "/token", "/upload")):
                endpoints.add(v)
    return {"input": str(input_path), "files_scanned": files,
            "endpoints": sorted(endpoints)[:60], "external_hosts": sorted(hosts)[:30],
            "boundary": "Static strings from local files; no requests sent."}


def probe_api(input_path: Path, out_dir: Path, finder=None, args=None) -> dict:
    spec = json.loads(Path(input_path).read_text(encoding="utf-8", errors="ignore"))
    global_security = spec.get("security")
    unauthenticated, routes = [], 0
    for route, ops in (spec.get("paths") or {}).items():
        for method, op in (ops or {}).items():
            if method.lower() not in API_METHODS or not isinstance(op, dict):
                continue
            routes += 1
            if global_security is None and not op.get("security"):
                unauthenticated.append(f"{method.upper()} {route}")
    return {"input": str(input_path), "title": (spec.get("info") or {}).get("title"),
            "routes": routes, "global_security": global_security,
            "routes_without_security": unauthenticated[:60],
            "boundary": "Spec-derived inventory only; a missing security block is a review "
                        "signal, not a confirmed auth bypass."}


def probe_oss(input_path: Path, out_dir: Path, finder=None, args=None) -> dict:
    patterns = OSS_PATTERNS
    hits = {name: [] for name, _ in patterns}
    files = 0
    root = Path(input_path)
    ext = {".py", ".js", ".mjs", ".ts", ".tsx", ".java", ".go", ".rb", ".php", ".rs", ".cs"}
    candidates = ([root] if root.is_file() else
                  [p for p in sorted(root.rglob("*"))
                   if p.is_file() and p.suffix.lower() in ext
                   and ".git" not in p.parts and "node_modules" not in p.parts])
    for p in candidates[:MAX_SCAN_FILES]:
        try:
            if p.stat().st_size > MAX_SCAN_BYTES:
                continue
            lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError:
            continue
        files += 1
        for n, line in enumerate(lines, 1):
            for name, rx in patterns:
                if rx.search(line) and len(hits[name]) < 25:
                    hits[name].append({"file": str(p.relative_to(root)) if root.is_dir() else p.name,
                                       "line": n, "text": line.strip()[:160]})
    return {"input": str(input_path), "files_scanned": files,
            "hits": {k: v for k, v in hits.items() if v},
            "boundary": "Static pattern matches in local source; not a validated finding."}


PROBES = {"ad": probe_ad, "web": probe_web, "api": probe_api, "oss": probe_oss}


def _count(items, key):
    out: dict = {}
    for it in items:
        out[it[key]] = out.get(it[key], 0) + 1
    return out


# --------------------------------------------------------------------------- #
# MCP surface agent
# --------------------------------------------------------------------------- #
def _tool(name, description, properties=None, required=(), readonly=True):
    return {"name": name, "description": description,
            "inputSchema": {"type": "object", "properties": properties or {},
                            "required": list(required), "additionalProperties": False},
            "annotations": {"readOnlyHint": readonly, "destructiveHint": False,
                            "openWorldHint": False}}


BASE_TOOLS = [
    _tool("agent_status", "Surface id, attempt ledger, workspace and knowledge-graph state."),
    _tool("agent_query_kg", "Query the shared BBTWIN2 knowledge graph.",
          {"query": {"type": "string", "maxLength": 500},
           "node_type": {"type": "string"}, "limit": {"type": "integer"}}, ("query",)),
    _tool("agent_query_vectors", "Search the agent-shared hybrid vector index.",
          {"query": {"type": "string", "maxLength": 500},
           "limit": {"type": "integer"}}, ("query",)),
    _tool("agent_probe", "Run this surface's bounded read-only local probe."),
    _tool("agent_capabilities",
          "Return the AD capability packet (principal -> capability -> crown-jewel target) "
          "for handoff to the other surfaces. AD computes it; others read the shared packet."),
    _tool("agent_send", "Send a message to another surface agent ('AD'/'WEB'/'API'/'OSS'), "
                        "'coordinator', or 'all'.",
          {"to": {"type": "string"}, "topic": {"type": "string", "maxLength": 120},
           "body": {"type": "string", "maxLength": 4000}}, ("to", "topic", "body"), False),
    _tool("agent_inbox", "Read messages addressed to this surface (broadcasts included).",
          {"limit": {"type": "integer"}, "unread_only": {"type": "boolean"}}),
    _tool("agent_claim", "Record one hypothesis with a falsifier and source refs. "
                         "Consumes one of the 5 attempts.",
          {"hypothesis": {"type": "string", "maxLength": 1200},
           "falsifier": {"type": "string", "maxLength": 600},
           "source_refs": {"type": "array", "items": {"type": "string"}},
           "controls": {"type": "array", "items": {"type": "string"}},
           "status": {"type": "string", "enum": ["supported", "hold", "reject", "unresolved"]}},
          ("hypothesis", "falsifier", "source_refs"), False),
    _tool("agent_publish", "Store an artifact/observation into the shared store.",
          {"label": {"type": "string"}, "body": {"type": "string", "maxLength": 4000}},
          ("label", "body"), False),
    _tool("agent_handoff", "Report back to the coordinator: what was done, what is left. "
                           "Mandatory once the attempt budget is exhausted.",
          {"outcome": {"type": "string", "enum": ["resolved", "unresolved", "blocked"]},
           "done": {"type": "array", "items": {"type": "string"}},
           "left": {"type": "array", "items": {"type": "string"}},
           "blockers": {"type": "array", "items": {"type": "string"}},
           "next_hypothesis": {"type": "string"}},
          ("outcome", "done", "left"), False),
]


class SurfaceAgent:
    def __init__(self, surface, config, run, workspace=None, embedding=(None, None)):
        self.surface = surface
        self.config = config
        self.spec = config["surfaces"][surface]
        self.run = run
        ws = Path(workspace or config.get("workspace") or "data/surface-agents")
        if not ws.is_absolute():
            ws = HARNESS_ROOT / ws          # portable across machines (e.g. Leonardo $WORK)
        self.workspace = ws
        self.store = AgentStore(self.workspace / "agent_kg.sqlite3")
        self.vectors = SharedVectors(self.store, *embedding)
        self.graph = CanonicalGraph(config.get("methodology_graph")
                                    or CanonicalGraph().path)
        self.max_attempts = int(config.get("max_attempts", 5))

    def close(self):
        self.store.close()
        self.graph.close()

    def _input(self):
        raw = self.spec.get("input")
        return (self.workspace / raw) if raw and not Path(raw).is_absolute() else Path(raw or ".")

    def status(self):
        return {"surface": self.surface, "title": self.spec.get("title"),
                "run": self.run, "probe": self.spec.get("probe"),
                "attempts": self.store.attempts(self.run, self.surface, self.max_attempts),
                "knowledge_graph": self.graph.stats(),
                "vector_backend": self.vectors.backend,
                "boundary": "Read-only surface agent; no target traffic, no PoC execution."}

    def call(self, name, args):
        if name == "agent_status":
            return self.status()
        if name == "agent_query_kg":
            return {"query": args["query"],
                    "nodes": self.graph.search(args["query"], args.get("node_type"),
                                               limit=args.get("limit", 10))}
        if name == "agent_query_vectors":
            return self.vectors.search(self.run, args["query"], args.get("limit", 4))
        if name == "agent_probe":
            probe = PROBES.get(self.spec.get("probe"))
            if probe is None:
                raise ValueError(f"unknown probe {self.spec.get('probe')!r}")
            result = probe(self._input(), self.workspace / "runs" / self.run / self.surface,
                           self.config.get("bloodhound_finder", DEFAULT_FINDER),
                           self.spec.get("probe_args", {}))
            self.store.message(self.run, self.surface, "coordinator", "probe", {"surface": self.surface})
            self.vectors.add(self.run, self.surface, f"{self.surface}:probe",
                             json.dumps(result)[:3900])
            return result
        if name == "agent_capabilities":
            if self.surface == "AD":
                src = self._input()
                graph = (json.loads(src.read_text(encoding="utf-8"))
                         if src.is_file() and src.suffix == ".json"
                         else canonicalize_bloodhound(src))
                ledger = capability_ledger(graph)
                packet = {
                    "schema": "bbtwin.capability-packet/v1", "source": "AD",
                    "totals": ledger["summary"],
                    "reachable_high_value_targets": ledger["reachable_high_value_targets"],
                    "identities_with_direct_control": sorted({
                        c["from"]["name"] for c in ledger["direct_capabilities"]
                        if c["capability"] in ("DCSYNC", "GENERICALL", "WRITEDACL", "WRITEOWNER",
                                               "OWNS", "FORCECHANGEPASSWORD", "ALLOWEDTOACT",
                                               "ALLOWEDDELEGATION")
                        and c["target_high_value"]}),
                    "high_value_edges": [c for c in ledger["direct_capabilities"]
                                         if c["target_high_value"]][:300],
                    "boundary": ledger["capability_boundary"],
                }
                self.vectors.add(self.run, "AD", "AD:capabilities", json.dumps(packet))
                self.store.message(self.run, "AD", "coordinator", "capabilities",
                                   {"totals": packet["totals"]})
                return packet
            shared = self.store.latest_vector(self.run, "AD:capabilities")
            if not shared:
                raise ValueError("no AD capability packet for this run; ask the AD surface first")
            return {"source": "AD", "via": "shared-store", "packet": json.loads(shared["body"])}
        if name == "agent_send":
            if not str(args.get("to") or "").strip():
                raise ValueError("agent_send requires a destination")
            return self.store.send(self.run, self.surface, str(args["to"]).strip(),
                                   str(args.get("topic") or "note"), args.get("body"))
        if name == "agent_inbox":
            return {"surface": self.surface,
                    "messages": self.store.inbox(self.run, self.surface,
                                                 args.get("limit", 20),
                                                 args.get("unread_only", True))}
        if name == "agent_publish":
            vid = self.vectors.add(self.run, self.surface, args["label"], args["body"])
            self.store.message(self.run, self.surface, "coordinator", "publish",
                               {"label": args["label"], "vector_id": vid})
            return {"stored": vid, "label": args["label"]}
        if name == "agent_claim":
            cur = self.store.attempts(self.run, self.surface, self.max_attempts)
            if cur["used"] >= cur["max"]:
                raise ValueError(
                    f"attempt budget exhausted ({cur['used']}/{cur['max']}); call agent_handoff")
            refs = [str(r) for r in args.get("source_refs") or [] if str(r).strip()]
            if not refs:
                raise ValueError("source_refs required; a claim without provenance is not recorded")
            if not str(args.get("falsifier") or "").strip():
                raise ValueError("falsifier required; an unfalsifiable hypothesis is not recorded")
            new = self.store.bump_attempt(self.run, self.surface, self.max_attempts)
            cid = self.store.claim(self.run, self.surface, new["used"], args["hypothesis"],
                                   args["falsifier"], refs, args.get("controls") or [],
                                   args.get("status", "unresolved"))
            self.store.message(self.run, self.surface, "coordinator", "claim",
                               {"claim_id": cid, "attempt": new["used"], "status": args.get("status")})
            return {"claim_id": cid, "attempt": new["used"], "remaining": new["max"] - new["used"],
                    "status": args.get("status", "unresolved")}
        if name == "agent_handoff":
            cur = self.store.attempts(self.run, self.surface, self.max_attempts)
            hid = self.store.handoff(self.run, self.surface, args["outcome"], args["done"],
                                     args["left"], args.get("blockers") or [],
                                     args.get("next_hypothesis", ""),
                                     [str(self.workspace / "runs" / self.run / self.surface)],
                                     cur["used"])
            self.store.message(self.run, self.surface, "coordinator", "handoff",
                               {"handoff_id": hid, "outcome": args["outcome"]})
            return {"handoff_id": hid, "outcome": args["outcome"], "attempts_used": cur["used"],
                    "done": args["done"], "left": args["left"]}
        raise ValueError("unknown surface-agent tool")

    def dispatch(self, request):
        if not isinstance(request, dict):
            raise ValueError("JSON-RPC object required")
        method, ident = request.get("method"), request.get("id")
        if ident is None:
            return None
        try:
            if method == "initialize":
                return _ok(ident, {"protocolVersion": "2024-11-05",
                                   "capabilities": {"tools": {}},
                                   "serverInfo": {"name": f"surface-agent-{self.surface}",
                                                  "version": "1.0.0"},
                                   "instructions": "Read-only surface agent; local probes only."})
            if method == "ping":
                return _ok(ident, {})
            if method == "tools/list":
                return _ok(ident, {"tools": BASE_TOOLS})
            if method == "tools/call":
                p = request["params"]
                try:
                    with contextlib.redirect_stdout(sys.stderr):
                        value = self.call(p["name"], p.get("arguments", {}))
                    return _ok(ident, {"content": [{"type": "text", "text": json.dumps(value)}]})
                except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
                    return _ok(ident, {"isError": True,
                                       "content": [{"type": "text", "text": str(exc)}]})
            return {"jsonrpc": "2.0", "id": ident,
                    "error": {"code": -32601, "message": "Unsupported MCP method"}}
        except (ValueError, KeyError, TypeError) as exc:
            return {"jsonrpc": "2.0", "id": ident, "error": {"code": -32602, "message": str(exc)}}


def _ok(ident, result):
    return {"jsonrpc": "2.0", "id": ident, "result": result}


def load_config(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main(argv=None):
    ap = argparse.ArgumentParser(description="MCP surface agent")
    ap.add_argument("--surface", default="AD")
    ap.add_argument("--run", default="adhoc")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--workspace")
    ap.add_argument("--serve-stdio", action="store_true")
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--canonicalize", action="store_true",
                    help="write a normalized graph from --input (default: the AD surface input)")
    ap.add_argument("--capabilities", action="store_true",
                    help="print the AD capability ledger (principal -> capability -> target)")
    ap.add_argument("--input", help="dataset dir or normalized-graph.json")
    ap.add_argument("--out")
    args = ap.parse_args(argv)

    if args.canonicalize or args.capabilities:
        config = load_config(args.config)
        if args.workspace:
            config["workspace"] = args.workspace
        ad_input = config["surfaces"]["AD"]["input"]
        src = Path(args.input) if args.input else (
            Path(ad_input) if Path(ad_input).is_absolute()
            else Path(config["workspace"]) / ad_input)
        graph = (json.loads(src.read_text(encoding="utf-8"))
                 if src.is_file() and src.suffix == ".json"
                 else canonicalize_bloodhound(src))
        if args.canonicalize:
            target = Path(args.out) if args.out else DEFAULT_CONFIG.parent / "normalized-graph.json"
            target.write_text(json.dumps(graph, indent=1), encoding="utf-8")
            print(json.dumps({"nodes": len(graph["nodes"]), "edges": len(graph["edges"]),
                              "out": str(target)}, indent=2))
            return 0
        ledger = capability_ledger(graph)
        if args.out:
            Path(args.out).write_text(json.dumps(ledger, indent=1), encoding="utf-8")
        print(json.dumps(ledger, indent=2))
        return 0

    config = load_config(args.config)
    if args.workspace:
        config["workspace"] = args.workspace
    agent = SurfaceAgent(args.surface, config, args.run)
    try:
        if args.probe:
            print(json.dumps(agent.call("agent_probe", {}), indent=2))
        elif args.status:
            print(json.dumps(agent.status(), indent=2))
        else:  # default: stdio MCP server
            for line in sys.stdin:
                line = line.strip()
                if not line:
                    continue
                try:
                    reply = agent.dispatch(json.loads(line))
                except ValueError:
                    reply = {"jsonrpc": "2.0", "id": None,
                             "error": {"code": -32700, "message": "Invalid JSON"}}
                if reply is not None:
                    print(json.dumps(reply), flush=True)
    finally:
        agent.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())