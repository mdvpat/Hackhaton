#!/usr/bin/env bash
# Source this on Leonardo (login node or inside an allocation) to route outbound
# HTTP through the hackathon proxy while keeping loopback direct.
#
#   export LEONARDO_PROXY='http://hackathon:<PW>@10.99.0.7:24817'   # from the hackathon
#   source leonardo/proxy.sh
#
# No credential is stored in this repository: set LEONARDO_PROXY first.
# Compute nodes have no internet; the proxy lives on the login-node side.
set -a

if [ -z "${LEONARDO_PROXY:-}" ]; then
  case "${HTTPS_PROXY:-${https_proxy:-}}" in
    *@*|?*)  # already configured in the environment: reuse it
      LEONARDO_PROXY="$HTTPS_PROXY" ;;
    *)
      echo "proxy.sh: set LEONARDO_PROXY first, e.g." >&2
      echo "  export LEONARDO_PROXY='http://hackathon:<PW>@10.99.0.7:24817'" >&2
      return 1 2>/dev/null || exit 1 ;;
  esac
fi

P="$LEONARDO_PROXY"
HTTP_PROXY="$P"
HTTPS_PROXY="$P"
http_proxy="$P"
https_proxy="$P"
# Loopback (model bridge, local embedding server) must never go through the proxy.
NO_PROXY="127.0.0.1,localhost,::1${NO_PROXY:+,$NO_PROXY}"
no_proxy="$NO_PROXY"
set +a

echo "proxy     : $(printf '%s' "$HTTPS_PROXY" | sed -E 's#//[^@]*@#//***:***@#')"
echo "no_proxy  : $NO_PROXY"

# Verify (prints 404 when the proxy is reachable and working).
if command -v curl >/dev/null 2>&1; then
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://api.wandb.ai || true)
  echo "proxy test: HTTP ${code:-failed}  (404 = working)"
fi