"""Tests for the four-surface agent bus (kg_client + surface_agent + ledger)."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

from harness.kg_client import AgentStore, CanonicalGraph, SharedVectors
from harness.surface_agent import SurfaceAgent, canonicalize_bloodhound

BH_EXPORT = Path(__file__).resolve().parent.parent / "data" / "surface-agents" / "ad" / "company1"


def minimal_config(workspace, surfaces=("AD",)):
    return {
        "schema": 1, "max_attempts": 5, "workspace": str(workspace),
        "methodology_graph": "./data/knowledge/methodology.sqlite3",
        "surfaces": {s: {"title": s, "probe": "ad" if s == "AD" else "web",
                         "input": ".", "probe_args": {}} for s in surfaces},
    }


class CanonicalizeTests(unittest.TestCase):
    @unittest.skipUnless(BH_EXPORT.is_dir(), "BloodHound fixture not extracted")
    def test_bloodhound_v5_canonicalized(self):
        graph = canonicalize_bloodhound(BH_EXPORT)
        self.assertGreater(len(graph["nodes"]), 50)
        self.assertGreater(len(graph["edges"]), 100)
        types = {n["type"] for n in graph["nodes"]}
        for expected in ("USER", "GROUP", "COMPUTER", "DOMAIN"):
            self.assertIn(expected, types)

    @unittest.skipUnless(BH_EXPORT.is_dir(), "BloodHound fixture not extracted")
    def test_group_membership_and_acl_edges_present(self):
        graph = canonicalize_bloodhound(BH_EXPORT)
        etypes = {e["type"] for e in graph["edges"]}
        self.assertIn("MEMBEROF", etypes)
        self.assertTrue(etypes & {"GENERICALL", "WRITEDACL", "WRITEOWNER", "OWNS", "DCSYNC"})


class KnowledgeGraphTests(unittest.TestCase):
    def test_canonical_graph_is_read_only_and_searchable(self):
        graph = CanonicalGraph()
        stats = graph.stats()
        if not stats["available"]:
            self.skipTest("BBTWIN2 methodology graph not built")
        self.assertGreater(stats["nodes"], 100)
        hits = graph.search("authorization", limit=5)
        self.assertIsInstance(hits, list)
        graph.close()

    def test_vector_index_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = AgentStore(Path(tmp) / "agent_kg.sqlite3")
            vectors = SharedVectors(store)
            vectors.add("r1", "AD", "note", "kerberoastable service account with SPN")
            out = vectors.search("r1", "service account spn")
            self.assertTrue(out["results"])
            self.assertIn("claim_boundary", out)
            store.close()


class AttemptLedgerTests(unittest.TestCase):
    def _agent(self, tmp):
        return SurfaceAgent("AD", minimal_config(Path(tmp)), "run-test")

    def test_five_attempts_then_handoff_required(self):
        with tempfile.TemporaryDirectory() as tmp:
            agent = self._agent(tmp)
            try:
                for i in range(1, 6):
                    out = agent.call("agent_claim", {
                        "hypothesis": f"h{i}", "falsifier": "observable counter",
                        "source_refs": ["probe:AD"]})
                    self.assertEqual(out["attempt"], i)
                self.assertEqual(out["remaining"], 0)
                with self.assertRaises(ValueError):
                    agent.call("agent_claim", {"hypothesis": "h6", "falsifier": "x",
                                               "source_refs": ["probe:AD"]})
                hand = agent.call("agent_handoff", {
                    "outcome": "unresolved", "done": ["a"], "left": ["b"]})
                self.assertEqual(hand["outcome"], "unresolved")
                self.assertEqual(hand["attempts_used"], 5)
            finally:
                agent.close()

    def test_claim_without_provenance_or_falsifier_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            agent = self._agent(tmp)
            try:
                with self.assertRaises(ValueError):
                    agent.call("agent_claim", {"hypothesis": "h", "falsifier": "f",
                                               "source_refs": []})
                with self.assertRaises(ValueError):
                    agent.call("agent_claim", {"hypothesis": "h", "falsifier": "",
                                               "source_refs": ["x"]})
                self.assertEqual(agent.call("agent_status", {})["attempts"]["used"], 0)
            finally:
                agent.close()

    def test_rejected_claim_does_not_consume_budget(self):
        with tempfile.TemporaryDirectory() as tmp:
            agent = self._agent(tmp)
            try:
                with self.assertRaises(ValueError):
                    agent.call("agent_claim", {"hypothesis": "h", "falsifier": "",
                                               "source_refs": ["x"]})
                out = agent.call("agent_claim", {"hypothesis": "h", "falsifier": "f",
                                                 "source_refs": ["x"]})
                self.assertEqual(out["attempt"], 1)
            finally:
                agent.close()


class MCPProtocolTests(unittest.TestCase):
    def test_initialize_and_tools_list(self):
        with tempfile.TemporaryDirectory() as tmp:
            agent = SurfaceAgent("AD", minimal_config(Path(tmp)), "run-test")
            try:
                init = agent.dispatch({"jsonrpc": "2.0", "id": 1, "method": "initialize",
                                       "params": {}})
                self.assertEqual(init["result"]["serverInfo"]["name"], "surface-agent-AD")
                listed = agent.dispatch({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
                names = {t["name"] for t in listed["result"]["tools"]}
                self.assertIn("agent_claim", names)
                self.assertIn("agent_handoff", names)
                notif = agent.dispatch({"jsonrpc": "2.0", "method": "notifications/initialized"})
                self.assertIsNone(notif)
            finally:
                agent.close()


class BusFixtureTests(unittest.TestCase):
    def test_all_four_probe_kinds_are_registered(self):
        from harness.surface_agent import PROBES
        self.assertEqual(set(PROBES), {"ad", "web", "api", "oss"})

    def test_shipped_config_covers_four_surfaces(self):
        cfg = json.loads((Path(__file__).resolve().parent.parent / "harness" /
                          "surface_agents.json").read_text())
        self.assertEqual(set(cfg["surfaces"]), {"AD", "WEB", "API", "OSS"})


class SurfaceBusMCPTests(unittest.TestCase):
    def _server(self, tmp):
        from harness.surface_bus_mcp import SurfaceBusServer
        config = Path(__file__).resolve().parent.parent / "harness" / "surface_agents.json"
        return SurfaceBusServer("bus-test", config, workspace=tmp)

    def test_tools_and_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            server = self._server(tmp)
            try:
                listed = server.dispatch({"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
                names = {t["name"] for t in listed["result"]["tools"]}
                self.assertIn("surface_probe", names)
                self.assertIn("surface_run", names)
                status = server.call("surface_bus_status", {})
                self.assertEqual(set(status["surfaces"]), {"AD", "WEB", "API", "OSS"})
            finally:
                server.close()

    def test_claim_requires_arguments_and_consumes_budget(self):
        with tempfile.TemporaryDirectory() as tmp:
            server = self._server(tmp)
            try:
                with self.assertRaises(ValueError):
                    server.call("surface_claim", {"surface": "API", "hypothesis": "h",
                                                  "falsifier": "f", "source_refs": []})
                out = server.call("surface_claim", {"surface": "API", "hypothesis": "h",
                                                    "falsifier": "f", "source_refs": ["x"]})
                self.assertEqual(out["attempt"], 1)
                ledger = server.call("surface_attempts", {})
                api = [a for a in ledger["attempts"] if a["surface"] == "API"][0]
                self.assertEqual(api["used"], 1)
            finally:
                server.close()

    def test_unknown_surface_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            server = self._server(tmp)
            try:
                with self.assertRaises(ValueError):
                    server.call("surface_probe", {"surface": "NOPE"})
            finally:
                server.close()


class CapabilityDiffTests(unittest.TestCase):
    def _module(self):
        import importlib.util
        path = (Path(__file__).resolve().parent.parent / "scripts" / "bh_capability_diff.py")
        spec = importlib.util.spec_from_file_location("bh_capability_diff", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    @staticmethod
    def _snap(name, caps):
        direct = {}
        for frm, capability, to, high_value in caps:
            key = f"{frm}|{capability}|{to}"
            direct[key] = {"key": key, "capability": capability, "from": frm, "from_id": frm,
                           "to": to, "to_id": to, "target_high_value": high_value}
        return {"dataset": name, "direct": direct, "inherited": {},
                "ledger": {"summary": {}}, "names": {}, "high_value": {}}

    def test_diff_reports_added_removed_and_escalation(self):
        module = self._module()
        base = self._snap("d1", [("alice", "GENERICREAD", "obj", False),
                                 ("bob", "ADMINTO", "srv", False)])
        other = self._snap("d2", [("alice", "GENERICREAD", "obj", False),
                                  ("alice", "DCSYNC", "DOMAIN ADMINS", True)])
        result = module.diff(base, other)
        self.assertEqual(result["counts"]["added"], 1)
        self.assertEqual(result["counts"]["removed"], 1)
        self.assertEqual(result["counts"]["unchanged"], 1)
        self.assertEqual(len(result["escalations"]), 1)
        self.assertEqual(result["escalations"][0]["capability"], "DCSYNC")

    def test_shipped_manifest_has_baseline_and_pending_slots(self):
        manifest = json.loads((Path(__file__).resolve().parent.parent / "data" /
                               "surface-agents" / "ad" / "datasets.json").read_text())
        statuses = [d["status"] for d in manifest["datasets"]]
        self.assertEqual(statuses.count("available"), 1)
        self.assertEqual(len(manifest["datasets"]), 3)


class AnonymizeTests(unittest.TestCase):
    @staticmethod
    def _module():
        import importlib.util
        path = Path(__file__).resolve().parent.parent / "scripts" / "bh_anonymize.py"
        spec = importlib.util.spec_from_file_location("bh_anonymize", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_anonymize_removes_identifiers_and_preserves_rids(self):
        module = self._module()
        with tempfile.TemporaryDirectory() as tmp:
            src, out = Path(tmp) / "src", Path(tmp) / "out"
            src.mkdir()
            domain, dsid = "CORP.LOCAL", "S-1-5-21-111-222-333"
            docs = {
                "20260101_domains.json": {"meta": {"type": "domains", "version": 5}, "data": [
                    {"ObjectIdentifier": dsid, "Properties": {
                        "name": domain, "domain": domain, "domainsid": dsid,
                        "highvalue": True, "distinguishedname": "DC=CORP,DC=LOCAL"}}]},
                "20260101_users.json": {"meta": {"type": "users", "version": 5}, "data": [
                    {"ObjectIdentifier": f"{dsid}-1101", "Properties": {
                        "name": f"J.DOE@{domain}", "samaccountname": "J.DOE", "domain": domain,
                        "domainsid": dsid,
                        "distinguishedname": "CN=J.DOE,CN=Users,DC=CORP,DC=LOCAL"}}]},
            }
            for name, doc in docs.items():
                (src / name).write_text(json.dumps(doc), encoding="utf-8")

            argv = sys.argv
            sys.argv = ["bh_anonymize.py", "--input", str(src), "--out", str(out),
                        "--domain", "AD.COMPANY1", "--seed", "test"]
            try:
                import contextlib
                import io
                with contextlib.redirect_stdout(io.StringIO()):
                    module.main()
            finally:
                sys.argv = argv

            blob = "\n".join(p.read_text() for p in out.glob("*.json")
                             if "SENSITIVE" not in p.name)
            for leaked in ("CORP", "LOCAL", "J.DOE"):
                self.assertNotIn(leaked, blob)

            users = json.loads((out / "20260101_users.json").read_text())["data"]
            self.assertTrue(users[0]["ObjectIdentifier"].endswith("-1101"))   # RID preserved
            self.assertEqual(users[0]["Properties"]["domain"], "AD.COMPANY1")
            domains = json.loads((out / "20260101_domains.json").read_text())["data"]
            self.assertEqual(domains[0]["Properties"]["name"], "AD.COMPANY1")
            self.assertNotEqual(domains[0]["ObjectIdentifier"], dsid)          # domain SID remapped
            self.assertTrue((out / "anonymization-mapping.SENSITIVE.json").is_file())


class LeonardoPortabilityTests(unittest.TestCase):
    """The tree must run off this machine: relative workspace, no external tools."""

    @unittest.skipUnless(BH_EXPORT.is_dir(), "BloodHound export not extracted")
    def test_ad_probe_without_external_finder(self):
        from harness.surface_agent import probe_ad
        with tempfile.TemporaryDirectory() as tmp:
            result = probe_ad(BH_EXPORT, Path(tmp),
                              finder=Path("/nonexistent/bloodhound_attack_path_finder.py"),
                              args={})
            self.assertIsNone(result["finder_rc"])
            self.assertIn("not present", result["finder_note"])
            self.assertGreater(result["capabilities"]["direct_capabilities"], 0)
            self.assertGreater(result["capabilities"]["high_value_capability_edges"], 0)
            self.assertTrue(Path(result["capability_ledger"]).is_file())

    def test_relative_workspace_resolves_against_package(self):
        from harness.kg_client import HARNESS_ROOT
        with tempfile.TemporaryDirectory() as tmp:
            config = minimal_config(tmp)
            config["workspace"] = "data/surface-agents"      # relative, as shipped
            agent = SurfaceAgent("AD", config, "portability")
            try:
                self.assertTrue(agent.workspace.is_absolute())
                self.assertEqual(agent.workspace, HARNESS_ROOT / "data" / "surface-agents")
            finally:
                agent.close()


class InterAgentMessagingTests(unittest.TestCase):
    def test_send_inbox_broadcast_consume_and_traffic(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = AgentStore(Path(tmp) / "kg.sqlite3")
            try:
                store.send("r1", "AD", "WEB", "AD:capabilities", {"identity": "USER-1"})
                store.broadcast("r1", "API", "API:probe-ready", {"routes": 3})
                inbox = store.inbox("r1", "WEB")
                self.assertEqual({m["topic"] for m in inbox},
                                 {"AD:capabilities", "API:probe-ready"})
                self.assertEqual(store.inbox("r1", "WEB"), [])          # consumed
                self.assertEqual(store.inbox("r1", "WEB", unread_only=False) != [], True)
                # a sender does not receive its own broadcast
                self.assertEqual([m for m in store.inbox("r1", "API", unread_only=False)
                                  if m["from"] == "API"], [])
                self.assertEqual(len(store.traffic("r1")), 2)
            finally:
                store.close()

    def test_surface_agents_exchange_messages(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = minimal_config(Path(tmp), surfaces=("AD", "WEB"))
            ad, web = SurfaceAgent("AD", config, "msg"), SurfaceAgent("WEB", config, "msg")
            try:
                ad.call("agent_send", {"to": "WEB", "topic": "AD:capabilities",
                                       "body": {"identity": "USER-1"}})
                got = web.call("agent_inbox", {})
                self.assertEqual(len(got["messages"]), 1)
                self.assertEqual(got["messages"][0]["topic"], "AD:capabilities")
                self.assertEqual(got["messages"][0]["from"], "AD")
                self.assertEqual(ad.call("agent_inbox", {})["messages"], [])
                with self.assertRaises(ValueError):
                    ad.call("agent_send", {"to": "  ", "topic": "x", "body": {}})
            finally:
                ad.close()
                web.close()


class ProxyTests(unittest.TestCase):
    def test_apply_sets_proxy_redacts_and_preserves_loopback(self):
        from harness import proxy
        saved = {k: os.environ.get(k) for k in (*proxy.PROXY_VARS, *proxy.NO_PROXY_VARS)}
        try:
            for key in saved:
                os.environ.pop(key, None)
            report = proxy.apply("http://hackathon:pw@10.99.0.7:24817")
            self.assertTrue(report["applied"])
            self.assertIn("***", report["proxy"])                 # credentials masked
            self.assertNotIn("pw", report["proxy"])
            for host in ("127.0.0.1", "localhost", "::1"):
                self.assertIn(host, report["no_proxy"])
            self.assertEqual(os.environ["HTTPS_PROXY"], "http://hackathon:pw@10.99.0.7:24817")

            merged = proxy.apply("http://10.99.0.7:24817", no_proxy="internal.example")
            self.assertIn("internal.example", merged["no_proxy"])
            self.assertIn("localhost", merged["no_proxy"])
        finally:
            for key, value in saved.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def test_validate_rejects_bad_input(self):
        from harness import proxy
        for bad in ("", "   ", "ftp://host:21", "http://"):
            with self.assertRaises(ValueError):
                proxy.validate(bad)

    def test_environment_does_not_mutate_process_env(self):
        from harness import proxy
        before = dict(os.environ)
        env = proxy.environment("http://10.99.0.7:24817")
        self.assertIn("10.99.0.7", env["HTTPS_PROXY"])
        self.assertIn("127.0.0.1", env["NO_PROXY"])
        self.assertEqual(dict(os.environ), before)


class AdCommsValidationTests(unittest.TestCase):
    @staticmethod
    def _module():
        import importlib.util
        path = Path(__file__).resolve().parent.parent / "scripts" / "ad_comms.py"
        spec = importlib.util.spec_from_file_location("ad_comms", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_validate_accepts_real_exchange_and_rejects_damage(self):
        module = self._module()
        with tempfile.TemporaryDirectory() as tmp:
            store = AgentStore(Path(tmp) / "kg.sqlite3")
            try:
                ad = {"dataset": "x", "graph": {"nodes": [], "edges": []},
                      "summary": {"direct_capabilities": 1, "inherited_capabilities": 0,
                                  "high_value_capability_edges": 1, "capabilities_by_type": {}},
                      "control_holders": ["A"], "dcsync_holders": ["A"],
                      "paths": [{"from": "a", "to": "b"}]}
                module.exchange(store, "t", ad, "objective", 5)
                rows = module.rows_for(store, "t")
                self.assertTrue(module.validate(rows, 5)["ok"])
                for missing in ("handoff", "AD:capabilities", "claim"):
                    damaged = [r for r in rows if r["topic"] != missing]
                    report = module.validate(damaged, 5)
                    self.assertFalse(report["ok"], f"dropping {missing} was not detected")
            finally:
                store.close()


if __name__ == "__main__":
    unittest.main()