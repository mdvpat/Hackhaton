# Surface-agent bus (four surfaces, one shared knowledge graph)

Local prototype for the Week-1 architecture: four read-only surface agents
(**AD / Web / API / OSS**) that talk over low-level MCP (line-delimited
JSON-RPC on stdio), share one knowledge graph and one vector index, and stop
after **5 attempts** with a structured handoff report.

## Why MCP and not MPI/OpenMP

MCP is what the qwenccrx6 harness already speaks (`--mcp-config`,
`harness/qwenccrx6_mcp.py`), it isolates one process per surface, and it gives
an auditable message trace. MPI/OpenMP are for tightly-coupled HPC compute,
not loosely-coupled agents — reserve them for the heavy kernels on Leonardo
(corpus embedding, graph algorithms), not for the message bus.

## Components

| File | Role |
|---|---|
| `harness/kg_client.py` | `CanonicalGraph` (read-only, `immutable=1` over BBTWIN2 `methodology.sqlite3`), `AgentStore` (append-only claims/handoffs/messages/vectors/attempts), `SharedVectors` (hybrid lexical+vector index; reuses `Embedder`) |
| `harness/surface_agent.py` | One MCP server per surface: `agent_status`, `agent_query_kg`, `agent_query_vectors`, `agent_probe`, `agent_claim`, `agent_publish`, `agent_handoff`; plus the SharpHound-v5 canonicalizer and the four local probes |
| `harness/agent_bus.py` | Coordinator: spawns the 4 servers, drives probe → KG/vector query → bounded claims → handoff, writes `runs/<run>/` artifacts |
| `harness/surface_agents.json` | Surface config (probe kind, input path, attempt budget, finder path) |
| `tests/test_surface_agent_bus.py` | 10 tests: canonicalizer, KG adapter, ledger, MCP protocol, config |

Data lives under `data/surface-agents/` (AD export under `ad/company1/`,
synthetic web/api/oss fixtures, `agent_kg.sqlite3`, `runs/<run>/`).

## Run

```bash
cd .
python3 -m harness.agent_bus --run demo-2          # four surfaces end-to-end
python3 -m harness.surface_agent --surface AD --run smoke --probe   # one surface
python3 -m unittest tests.test_surface_agent_bus -v
```

Artifacts per run: `bus-log.jsonl` (full message trace), `run-summary.json`
(ledger + outcomes + KG stats), `SURFACE-RUN.md` (readable report),
`<surface>/normalized-graph.json` (+ finder output for AD).

## Attempt-ledger contract

1. `agent_claim` requires a `hypothesis`, a `falsifier`, and non-empty
   `source_refs`. A claim without provenance or falsifier is **rejected before**
   consuming budget (an unfalsifiable hypothesis is not recorded).
2. Each accepted claim consumes exactly one attempt (max 5, from config).
3. At 5/5 the next claim is refused with `attempt budget exhausted; call
   agent_handoff`.
4. `agent_handoff` records *what was done*, *what is left*, blockers, the next
   best hypothesis and artifact paths — then the agent stops.
5. A clean `unresolved` is a valid result; the protocol never fabricates a
   finding to fill the report.

## AD surface: SharpHound v5

`bloodhound_attack_path_finder.py` selects sources by per-object `Type`, but
SharpHound v5 puts the type only in each file's `meta.type`. The prototype adds
`canonicalize_bloodhound()` (does not patch the user's tool): it infers the
type from file metadata, links group `Members` and `PrimaryGroupSID` as
`MEMBEROF`, maps `Aces` to ACL edges (collapsing `GetChanges` +
`GetChangesAll` to `DCSYNC`), and adds `ADMINTO` / `CANRDP` / `CANPSREMOTE` /
`EXECUTE-DCOM` / `HASSESSION` / delegation edges. The finder then runs on the
normalized graph.

First real run on `lab-export.zip` (`exam/20261001112908_bloodhound.zip`, a
SharpHound v5 export): **113 nodes / 836 edges** (27 users, 60 groups, 3
computers, 19 containers, 2 GPOs, 1 OU, 1 domain); 5 high-value targets
reached, **6 paths found**.

## Boundary

Every probe is static and local — no target traffic, no PoC execution, no
submission. `CanonicalGraph` opens the canonical model `immutable=1`; the bus
writes only its own `agent_kg.sqlite3`. Demo hypotheses in `agent_bus.py` are
illustrative labels, not validated findings.

## Next steps

- Point `AD` at the other two BloodHound datasets; add a 3-way graph diff.
- Swap the hashed-token vectors for a real embedding endpoint
  (`--embedding-endpoint/--embedding-model` wiring is already in `SharedVectors`).
- Attach the bus to qwenccrx6 with `--mcp-config` so a coordinator model can
  drive claims instead of the scripted demo.
- Reuse `cybertwin.ai/tools/cross_layer_solver.py` as the merge engine once
  Web/API/OSS produce real findings.