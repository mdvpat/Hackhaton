# BloodHound capability checker

The AD surface answers one question in a form the other three surfaces can use:
**which identity holds which capability over which crown-jewel target.**

A *capability* is a static right in the export — `GENERICALL`, `WRITEOWNER`,
`WRITEDACL`, `DCSYNC`, `ADMINTO`, delegation, and so on. It is not an executed
action. Nothing here authenticates, requests, or runs a path.

## Run it

```bash
cd .

# 1. normalize the export (SharpHound v5 -> {nodes,edges})
python3 -m harness.surface_agent --canonicalize \
  --input data/surface-agents/ad/company1 \
  --out data/surface-agents/runs/bh-check/normalized-graph.json

# 2. capability ledger (principal -> capability -> target)
python3 -m harness.surface_agent --capabilities \
  --out data/surface-agents/runs/bh-check/capability-ledger.json

# 3. readable report + cross-surface packet
python3 scripts/bh_capability_report.py \
  --graph  data/surface-agents/runs/bh-check/normalized-graph.json \
  --ledger data/surface-agents/runs/bh-check/capability-ledger.json \
  --out    data/surface-agents/runs/bh-check/CAPABILITIES.md

# 4. full attack-path enumeration (Jeff's finder) over the normalized graph
python3 ../cybertwin.ai/tools/bloodhound_attack_path_finder.py \
  data/surface-agents/runs/bh-check/normalized-graph.json \
  --target-mode all --path-mode all --max-depth 8 --path-limit 20000 \
  --top 25 --samples 25 --outdir data/surface-agents/runs/bh-check/finder-all
```

## Result on the lab export (SharpHound v5)

`lab-export.zip` → `exam/20261001112908_bloodhound.zip`.

| Metric | Value |
|---|---|
| Nodes / edges | 113 / 836 |
| Users / groups / computers | 27 / 60 / 3 |
| Direct capabilities | 769 |
| Inherited capabilities (via group membership) | 689 |
| High-value capability edges | 108 |
| **Paths enumerated (all mode)** | **120,203** |

Capabilities by type: `GENERICALL 231 · WRITEOWNER 153 · WRITEDACL 153 ·
GENERICWRITE 122 · OWNS 105 · ADMINTO 3 · DCSYNC 2`.

## The capabilities that matter

Identities holding a direct control capability over a high-value target:

| Identity | Capability | Target |
|---|---|---|
| `USER-9E6E@AD.COMPANY1` | **DCSYNC** | `AD.COMPANY1` (the domain) |
| `ADMINISTRATORS@AD.COMPANY1` | DCSYNC | `AD.COMPANY1` |
| `DOMAIN ADMINS@AD.COMPANY1` | GENERICWRITE / OWNS / WRITEDACL | Enterprise Key Admins, Account/Server/Backup/Print Operators, Schema Admins, KRBTGT |
| `ENTERPRISE ADMINS@AD.COMPANY1` | GENERICALL / GENERICWRITE | `AD.COMPANY1`, Enterprise Key Admins |
| `USER-57F3@AD.COMPANY1` | MEMBEROF | `DOMAIN ADMINS` |
| `USER-088C@AD.COMPANY1` | MEMBEROF | `DOMAIN ADMINS` |
| `ADMINISTRATOR@AD.COMPANY1` | MEMBEROF | `DOMAIN ADMINS` |

`DCSYNC` is the notable one: it is the collapse of `GetChanges` +
`GetChangesAll` on the domain object, i.e. a principal that can replicate
secret material. **USER-9E6E is a plain user, not an administrator.**

## Handing capabilities to the other surfaces

`agent_capabilities` returns a packet; the AD agent writes it to the shared
store as `AD:capabilities`, and any other surface reads it back:

```text
surface_capabilities(surface="AD")   -> computes the packet
surface_capabilities(surface="WEB")  -> via: "shared-store", packet: {…}
```

Packet schema `bbtwin.capability-packet/v1`:

```json
{
  "schema": "bbtwin.capability-packet/v1",
  "source": "AD",
  "totals": {"direct_capabilities": 769, "high_value_capability_edges": 108, "...": "..."},
  "reachable_high_value_targets": {"DOMAIN ADMINS@AD.COMPANY1": ["USER-9E6E@AD.COMPANY1", "..."]},
  "identities_with_direct_control": ["ADMINISTRATORS@AD.COMPANY1", "DOMAIN ADMINS@AD.COMPANY1",
                                     "ENTERPRISE ADMINS@AD.COMPANY1", "USER-9E6E@AD.COMPANY1"],
  "high_value_edges": [{"capability": "DCSYNC", "from": {"name": "USER-9E6E@AD.COMPANY1", "...": "..."},
                        "to": {"name": "AD.COMPANY1@AD.COMPANY1"}, "target_high_value": true}],
  "boundary": "Static ACL/access edges; a capability is not an executed action."
}
```

This is the language the surfaces exchange: **identity × capability × target**.
Web/API/OSS can then ask "does this identity also appear here?" instead of
guessing from names.

## Artifacts

| File | Contents |
|---|---|
| `normalized-graph.json` | SharpHound v5 → `{nodes, edges}` |
| `capability-ledger.json` | full direct + inherited capability ledger |
| `CAPABILITIES.md` | readable report (totals, control holders, shortest paths) |
| `CAPABILITIES.json` | cross-surface capability packet |
| `finder-all/` | all-mode attack-path enumeration (120,203 paths) |

## Dataset drift (N datasets)

Datasets are registered in `data/surface-agents/ad/datasets.json` (path relative
to the workspace). The first `available` entry is the baseline; the rest are
compared against it. Pending entries are skipped, so the file can list all three
while only one exists.

```bash
python3 scripts/bh_capability_diff.py \
  --manifest data/surface-agents/ad/datasets.json \
  --out data/surface-agents/runs/cap-diff
```

Capabilities are keyed `from_id|capability|to_id`, so a SID-stable export gives a
clean diff. The report classifies each change as **added**, **removed**
(hardening) or **unchanged**, and calls out *escalations* — a newly added
control capability (`DCSYNC`, `GENERICALL`, `WRITEDACL`, `WRITEOWNER`, `OWNS`,
`ForceChangePassword`, delegation) pointing at a high-value target — plus the
most-changed identities.

Current state (baseline only): `cap-diff/CAPABILITY-DIFF.md` — 108 high-value
edges, `USER-9E6E` holding `DCSYNC` over the domain, no comparison yet.

## Anonymized twin (`AD.COMPANY1`)

```bash
python3 scripts/bh_anonymize.py \
  --input data/surface-agents/ad/company1 \
  --out   data/surface-agents/ad/company1 \
  --domain AD.COMPANY1 --seed bbtwin
```

Deterministic per `--seed`. It rewrites the domain, the domain SID prefix, every
object name, `samaccountname`, DN, SPN, `dnshostname`, `gpcpath` and `description`;
it **preserves RIDs**, keeps well-known group names (so high-value logic still
applies), and never touches the SharpHound `meta` block (the canonicalizer needs
`meta.type`). A `anonymization-mapping.SENSITIVE.json` records old→new for the
operator — **local only, never ship it with the export**.

Proof it is faithful — `scripts/bh_capability_diff.py --structural` keys
capabilities by RID (stable across renaming and SID remapping):

```text
oscp-exam → company1-anon:  added 0 · removed 0 · unchanged 769   → PRESERVED
```

Counts after anonymization are identical: 113 nodes / 836 edges / 769 direct /
689 inherited / 108 high-value edges, and the same four identities reach a
high-value target (`USER-E6A1` = the DCSync user, `USER-FFB2`, `USER-B7E8`,
`ADMINISTRATOR`). Note `--structural` is what makes this check meaningful: the
default SID keying reports every row as added+removed, because the identifiers
were intentionally rewritten.

## Boundary

Static analysis of a supplied export. No authentication, no request, no path
execution, no submission. A capability is an ACL fact, not a demonstrated
exploit; reachability still needs a causal control before it becomes a finding.