---
name: surface-bus
description: Drive and extend the four-surface agent bus (AD/WEB/API/OSS) — probe, message between agents, claim with a falsifier, and hand off after 5 attempts.
---

# surface-bus

Use when you are running or extending the four surface agents.

## Invariants

- Every agent is **read-only** and local. No target traffic, no PoC execution, no submission.
- A claim **must** carry a `falsifier` and non-empty `source_refs`; otherwise it is
  rejected before consuming budget.
- **5 attempts** per surface, then `agent_handoff` (or `surface_handoff`) with
  done / left / blockers / next hypothesis. A clean `unresolved` is a valid result —
  never fabricate a finding to fill the report.
- Model agreement or vector similarity is **not** validation.

## Tools

| Surface agent | Bus (frontend) MCP |
|---|---|
| `agent_status` | `surface_bus_status` |
| `agent_probe` | `surface_probe` |
| `agent_capabilities` | `surface_capabilities` |
| `agent_send` / `agent_inbox` | `surface_send` / `surface_inbox` / `surface_traffic` |
| `agent_query_kg` / `agent_query_vectors` | `surface_query_kg` / `surface_query_vectors` |
| `agent_claim` / `agent_handoff` | `surface_claim` / `surface_handoff` |

## Recipe

1. `surface_bus_status` — confirm surfaces, budgets, KG state.
2. `surface_probe` per surface (AD first: it owns capabilities).
3. `surface_capabilities` — the AD capability packet; other surfaces read it from the
   shared store.
4. `surface_send(to="all", topic=..., body=...)` to share findings; `surface_inbox` to read.
5. `surface_claim` with a real falsifier; `surface_handoff` at 5 attempts.

## Run

```bash
python3 -m harness.agent_bus --run <run-id>        # coordinator drives all four
python3 -m harness.surface_agent --surface AD --run <run-id> --probe
python3 -m unittest tests.test_surface_agent_bus -v
```