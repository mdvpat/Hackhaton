---
name: nsight-profile
description: Profile the harness with NVIDIA Nsight Systems (timeline) and Nsight Compute (kernels) to locate the real bottleneck before porting anything to the GPU.
---

# nsight-profile

Use when asked to profile the code, justify a GPU port, or measure a speedup.

## Rule: measure before porting

Profile the **whole four-surface run** first. The bottleneck is usually not where
it is assumed to be (often the LLM round-trips and SQLite, not the graph).

## Commands

```bash
# timeline of one full run (CPU stages, CUDA, I/O)
nsys profile --trace=cuda,nvtx,osrt,python \
  --output runs/prof/<run> --force-overwrite true \
  python3 -m harness.agent_bus --run <run>

# summarise the timeline
nsys stats runs/prof/<run>.nsys-rep

# kernel-level detail on a chosen kernel
ncu --set full --target-processes all -k <kernel-regex> \
  python3 scripts/<script>.py
```

Add `--trace-fork-before-exec=true` when profiling the frontend, which spawns
subprocesses (bridges, MCP servers).

## What to attribute

| Stage | Where | Expected |
|---|---|---|
| capability ledger | `surface_agent.capability_ledger` | CPU, graph-bound |
| embedding + cosine | `knowledge_memory.Embedder`, `kg_client.SharedVectors` | CPU today → GPU candidate |
| model prefill/decode | model server (vLLM/llama.cpp) | GPU |
| tool-call round trips | `agent_bus.MCPClient` (stdio JSON-RPC) | serialisation/IPC overhead |

## Porting order (justified by the timeline, not by intuition)

1. batched embedding + top-k cosine → PyTorch / cuVS
2. transitive closure, multi-source BFS/SSSP, capability join → cuGraph + cuDF
3. transformer inference — already on GPU; profile, do not port

OpenACC/OpenMP apply only if stage 2 is rewritten in C/C++ (OpenMP for CPU
parallelism, OpenACC to offload). The Python harness ports via CUDA libraries.

## Deliverable

An `nsys` timeline of one run, an `ncu` pass on the chosen kernels, and a before/
after table with the measured numbers — no estimated speedups.