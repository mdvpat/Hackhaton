---
name: bh-capabilities
description: Build the BloodHound capability ledger, anonymize an export to AD.COMPANY1, and diff capabilities across datasets. Use for AD/SharpHound analysis and capability drift.
---

# bh-capabilities

Use when asked about AD attack paths, capabilities, BloodHound exports, or
dataset drift.

## The unit of exchange is a capability: identity x capability x target

A capability is a **static ACL fact**, not an executed action. It is not a finding
until a causal control demonstrates reachability.

## Commands

```bash
# normalize a SharpHound v5 export (vendor type lives in meta.type; principal
# refs are sometimes objects, not SIDs — the canonicalizer handles both)
python3 -m harness.surface_agent --canonicalize \
  --input data/surface-agents/ad/company1 --out runs/x/normalized-graph.json

# capability ledger (direct + inherited via transitive group membership)
python3 -m harness.surface_agent --capabilities --out runs/x/capability-ledger.json

# readable report + cross-surface packet
python3 scripts/bh_capability_report.py \
  --graph runs/x/normalized-graph.json --ledger runs/x/capability-ledger.json \
  --out runs/x/CAPABILITIES.md

# anonymize an export before it leaves the machine
python3 scripts/bh_anonymize.py --input ad/company1 --out ad/company1 \
  --domain AD.COMPANY1 --seed <seed>

# capability drift across datasets
python3 scripts/bh_capability_diff.py --manifest ad/datasets.json \
  --out runs/cap-diff [--structural]
```

## Rules learned the hard way

- `--structural` keys capabilities by **RID**, so a renamed/anonymized export
  compares on structure (expected: 0 drift). Default SID keying reports every row
  changed after a rewrite — that is expected, not drift.
- The domain SID (`S-1-5-21-a-b-c`) has **no RID**; treat it as a constant marker.
- An anonymizer must **never** scrub the SharpHound `meta` block: rewriting
  `meta.type` (`users` → `Users`) silently strips every node type downstream.
- Scrub **list-of-strings** too (SPNs, `dnshostname`, `gpcpath`) and `domainsid`;
  those leak identifiers otherwise.
- The external path finder is **optional** — the capability ledger does not need it.