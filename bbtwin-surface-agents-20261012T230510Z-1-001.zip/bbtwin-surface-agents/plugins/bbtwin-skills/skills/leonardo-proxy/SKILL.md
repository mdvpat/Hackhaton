---
name: leonardo-proxy
description: Route the harness through the CINECA Leonardo hackathon proxy. Compute nodes are offline and the login node has no GPU — this covers proxy env, NO_PROXY loopback, and Slurm placement.
---

# leonardo-proxy

Use when running the harness on CINECA Leonardo (or any offline compute node
behind a proxy).

## Facts

- **Login node**: has internet (via proxy) but **no GPU**.
- **Compute nodes**: have a GPU but **no internet** — any outbound call must go
  through the proxy, and any install must happen on the login node.
- Loopback (the model bridge, a local embedding/vLLM server) must **bypass** the
  proxy, otherwise the frontend cannot reach its own bridge.

## Enable

```bash
source leonardo/proxy.sh          # sets HTTP(S)_PROXY + NO_PROXY, then tests
# or per-run:
python3 -m harness.qwenccrx6 --proxy http://hackathon:<pw>@10.99.0.7:24817 ...
```

The proxy is applied to the process env (`harness/proxy.py :: apply`), and
`NO_PROXY` always gains `127.0.0.1,localhost,::1`. `harness/proxy.py :: redact()`
masks credentials before anything is logged.

## Where the harness makes outbound calls

| Path | Behaviour |
|---|---|
| embedding endpoint (`Embedder.encode`) | honours `HTTP(S)_PROXY`; loopback stays direct |
| model server / frontend bridge | loopback, bypasses the proxy |
| surface probes | static/local — no network |
| model/bridge downloads | **login node only** |

## Placement

```bash
srun --account=EUHPC_D30_031 -p boost_usr_prod -N1 --gres=gpu:1 -c8 \
     --mem=120GB -t 02:00:00 --pty bash        # interactive GPU shell
sbatch job-bbtwin-smoke.sbatch                 # batch
```

Verify the proxy inside a job:
```bash
curl -s -o /dev/null -w "%{http_code}\n" https://api.wandb.ai    # 404 == working
```

## Pitfalls

- Do not `pixi add` on a compute node — no internet, and it hangs.
- `scp`/`rsync` do not expand `$WORK`; resolve it with `ssh 'echo $WORK'`. For the
  CINECA layout that is `/leonardo_work/EUHPC_D30_031`.