# AGENTS.md — surface-bus demo

Local, read-only four-surface agent twin (AD / Web / API / OSS) over synthetic or
owned fixtures. Shared knowledge graph = BBTWIN2 methodology graph (read-only).

Hard boundaries: no public-target traffic, no PoC execution, no submission.
Claims require a falsifier and source references. Five attempts per surface,
then a structured handoff.