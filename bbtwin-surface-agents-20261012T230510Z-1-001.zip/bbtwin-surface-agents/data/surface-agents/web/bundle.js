// Synthetic SPA bundle fragment (test fixture — not a real target).
const API_BASE = "https://api.example.test/v2";
export async function loadProfile(id) {
  return fetch(`${API_BASE}/users/${id}/profile`);
}
export const routes = ["/api/v1/session", "/api/v1/orders", "/admin/health", "/graphql"];
const fallback = "https://cdn.example.test/assets/app.js";
// token: "eyTESTONLY-not-a-real-secret-0000"
function render(el, data) { el.innerHTML = data.bio; }