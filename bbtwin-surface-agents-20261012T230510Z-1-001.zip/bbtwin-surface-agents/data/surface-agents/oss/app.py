# Synthetic source fixture (test only — not a real repository).
import os
import subprocess
import pickle


def run_report(name):
    # command_exec sink reachable from a request parameter
    return subprocess.run(["report", name], capture_output=True)


def load_doc(blob):
    return pickle.loads(blob)


def fetch(url):
    import requests
    return requests.get(url)


API_KEY = "example-only-0000000000"