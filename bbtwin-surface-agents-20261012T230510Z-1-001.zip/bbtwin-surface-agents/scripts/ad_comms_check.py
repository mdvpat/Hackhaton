#!/usr/bin/env python3
"""Check + profile the AD-set agent <-> orchestrator communication, locally.

Runs the real AD pipeline, emits the conversation through the real AgentStore,
asserts it is well formed, and reports stage timings. Exit code 1 if a check
fails, so it works as a gate.

Usage:
  python3 scripts/ad_comms_check.py [--ad data/surface-agents/ad/company1]
      [--run ad-comms-1] [--out data/surface-agents/runs]
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness.kg_client import AgentStore, HARNESS_ROOT  # noqa: E402
from harness.surface_agent import capability_ledger, canonicalize_bloodhound  # noqa: E402
import ad_comms  # noqa: E402


def ms(fn, repeats=3):
    samples = []
    value = None
    for _ in range(max(1, repeats)):
        start = time.perf_counter()
        value = fn()
        samples.append((time.perf_counter() - start) * 1000)
    return statistics.median(samples), value


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ad")
    ap.add_argument("--run", default="ad-comms-1")
    ap.add_argument("--out", default="data/surface-agents/runs")
    ap.add_argument("--objective", default="Enumerate AD capabilities and crown-jewel paths.")
    ap.add_argument("--repeats", type=int, default=3)
    args = ap.parse_args()

    config = json.loads((HARNESS_ROOT / "harness" / "surface_agents.json").read_text())
    budget = int(config.get("max_attempts", 5))
    ad_path = ad_comms.resolve_ad(args.ad)
    out_root = Path(args.out)
    if not out_root.is_absolute():
        out_root = HARNESS_ROOT / out_root

    timings: dict[str, float] = {}
    graph = canonicalize_bloodhound(ad_path)
    timings["canonicalize_bloodhound_ms"], _ = ms(lambda: canonicalize_bloodhound(ad_path),
                                                  args.repeats)
    ledger = capability_ledger(graph)
    timings["capability_ledger_ms"], _ = ms(lambda: capability_ledger(graph), args.repeats)
    timings["shortest_paths_ms"], paths = ms(lambda: ad_comms.shortest_paths(graph), args.repeats)

    ad = {"dataset": str(ad_path), "graph": graph, "ledger": ledger,
          "summary": ledger["summary"],
          "control_holders": sorted({c["from"]["name"] for c in ledger["direct_capabilities"]
                                     if c["capability"] in ad_comms.CONTROL
                                     and c["target_high_value"]}),
          "dcsync_holders": sorted({c["from"]["name"] for c in ledger["direct_capabilities"]
                                    if c["capability"] == "DCSYNC"}),
          "paths": paths}

    run = args.run
    store = AgentStore(out_root.parent / "agent_kg.sqlite3")
    store.db.execute("DELETE FROM messages WHERE run=?", (run,))
    store.db.commit()

    start = time.perf_counter()
    ad_comms.exchange(store, run, ad, args.objective, budget)
    timings["exchange_emit_ms"] = (time.perf_counter() - start) * 1000

    rows = ad_comms.rows_for(store, run)
    timings["validate_ms"], report = ms(lambda: ad_comms.validate(rows, budget), 1)

    # end-to-end: can AD actually consume what the orchestrator sends it?
    start = time.perf_counter()
    inbox = store.inbox(run, "AD", unread_only=False)
    timings["inbox_read_ms"] = (time.perf_counter() - start) * 1000

    run_dir = out_root / run
    run_dir.mkdir(parents=True, exist_ok=True)
    result = {"run": run, "dataset": str(ad_path), "budget": budget,
              "timings_ms": {k: round(v, 4) for k, v in timings.items()},
              "messages": len(rows),
              "ad_inbox_size": len(inbox),
              "control_holders": ad["control_holders"], "dcsync_holders": ad["dcsync_holders"],
              "crown_jewel_paths": len(ad["paths"]),
              "validation": report}
    (run_dir / "ad-comms-check.json").write_text(json.dumps(result, indent=2), encoding="utf-8")

    lines = [f"# AD-set communication check — run {run}", "",
             f"Dataset: `{ad_path}`   Budget: {budget}", "",
             "## Checks", ""]
    for c in report["checks"]:
        lines.append(f"- [{'ok' if c['ok'] else 'FAIL'}] {c['check']}"
                     + (f" — {c['detail']}" if c["detail"] and not c["ok"] else ""))
    lines += ["", "## Timings (median)", "", "| stage | ms |", "|---|---:|"]
    for name, value in result["timings_ms"].items():
        lines.append(f"| {name} | {value} |")
    lines += ["", f"Messages: {len(rows)}  |  AD inbox: {len(inbox)}  |  "
              f"crown-jewel paths: {len(ad['paths'])}",
              f"DCSync holders: {ad['dcsync_holders']}", "",
              f"**Verdict: {'PASS' if report['ok'] else 'FAIL — ' + '; '.join(report['problems'])}**",
              ""]
    (run_dir / "AD-COMMS-CHECK.md").write_text("\n".join(lines), encoding="utf-8")

    print("\n".join(lines))
    print(f"wrote {run_dir/'AD-COMMS-CHECK.md'} and ad-comms-check.json")
    store.close()
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())