#!/usr/bin/env python3
"""Capability drift across BloodHound datasets.

Takes N SharpHound datasets, canonicalizes each, builds the capability ledger
(identity -> capability -> target), and reports what changed between the
baseline and every other dataset. With one dataset it reports the baseline and
marks the comparison as unavailable. Nothing is executed; static ACL facts only.

Usage:
  python3 scripts/bh_capability_diff.py \
      --manifest data/surface-agents/ad/datasets.json \
      --out data/surface-agents/runs/cap-diff
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from harness.kg_client import HARNESS_ROOT  # noqa: E402
from harness.surface_agent import capability_ledger, canonicalize_bloodhound, is_high_value  # noqa: E402

ESCALATING = {"DCSYNC", "GENERICALL", "WRITEDACL", "WRITEOWNER", "OWNS",
              "FORCECHANGEPASSWORD", "ALLOWEDTOACT", "ALLOWEDDELEGATION"}


def _rid(value: str) -> str:
    """Stable identity key across renames and domain-SID remapping.

    Object SIDs end in a RID; the domain SID itself (S-1-5-21-a-b-c) has none,
    so it gets a constant marker instead of its randomly-generated sub-authority.
    """
    parts = str(value).split("-")
    if len(parts) == 7 and parts[:4] == ["S", "1", "5", "21"]:
        return "DOMAIN"
    for part in reversed(parts):
        if part.isdigit():
            return part
    return str(value)


def snapshot(dataset: dict, key_mode: str = "sid") -> dict:
    graph = canonicalize_bloodhound(Path(dataset["path"]))
    ledger = capability_ledger(graph)
    name = {n["id"]: n["name"] for n in graph["nodes"]}
    hv = {n["id"]: is_high_value(n["name"], n) for n in graph["nodes"]}
    key_of = _rid if key_mode == "rid" else (lambda v: v)

    direct = {}
    for cap in ledger["direct_capabilities"]:
        key = f"{key_of(cap['from']['id'])}|{cap['capability']}|{key_of(cap['to']['id'])}"
        direct[key] = {"key": key, "capability": cap["capability"],
                       "from": cap["from"]["name"], "from_id": cap["from"]["id"],
                       "to": cap["to"]["name"], "to_id": cap["to"]["id"],
                       "target_high_value": bool(cap["target_high_value"])}
    inherited = {}
    for row in ledger["inherited_capabilities"]:
        key = f"{row['from']}|{row['capability']}|{row['via_group']}|{row['to']}"
        inherited[key] = row
    return {"dataset": dataset["name"], "path": str(dataset["path"]),
            "ledger": ledger, "direct": direct, "inherited": inherited,
            "names": name, "high_value": hv}


def diff(base: dict, other: dict) -> dict:
    base_keys, other_keys = set(base["direct"]), set(other["direct"])
    added = [other["direct"][k] for k in other_keys - base_keys]
    removed = [base["direct"][k] for k in base_keys - other_keys]
    shared = base_keys & other_keys

    def rank(rows):
        return sorted(rows, key=lambda r: (not r["target_high_value"], r["capability"]))

    escalations = [r for r in added if r["capability"] in ESCALATING and r["target_high_value"]]
    deferred = [r for r in removed if r["capability"] in ESCALATING and r["target_high_value"]]

    per_identity: dict[str, dict] = {}
    for r in added:
        per_identity.setdefault(r["from"], {"gained": 0, "lost": 0})["gained"] += 1
    for r in removed:
        per_identity.setdefault(r["from"], {"gained": 0, "lost": 0})["lost"] += 1

    return {
        "from": base["dataset"], "to": other["dataset"],
        "counts": {"baseline": len(base_keys), "other": len(other_keys),
                   "unchanged": len(shared), "added": len(added), "removed": len(removed)},
        "escalations": rank(escalations)[:60],
        "reductions": rank(deferred)[:60],
        "added": rank(added)[:120],
        "removed": rank(removed)[:120],
        "identities_changed": dict(sorted(per_identity.items(),
                                          key=lambda kv: -(kv[1]["gained"] + kv[1]["lost"]))),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--workspace")
    ap.add_argument("--structural", action="store_true",
                    help="key capabilities by RID instead of SID, so renamed/anonymized "
                         "exports compare on structure (expected: no drift)")
    args = ap.parse_args()

    manifest = json.loads(Path(args.manifest).read_text())
    workspace = Path(args.workspace or manifest.get("workspace") or "data/surface-agents")
    if not workspace.is_absolute():
        workspace = HARNESS_ROOT / workspace
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    available, skipped = [], []
    for ds in manifest["datasets"]:
        if ds.get("status") != "available" or not ds.get("path"):
            skipped.append({"name": ds["name"], "status": ds.get("status", "pending")})
            continue
        path = Path(ds["path"])
        entry = dict(ds, path=str(path if path.is_absolute() else workspace / path))
        if not Path(entry["path"]).exists():
            skipped.append({"name": ds["name"], "status": "path-missing",
                            "path": entry["path"]})
            continue
        available.append(entry)

    if not available:
        raise SystemExit("no available datasets with a resolvable path")

    key_mode = "rid" if args.structural else "sid"
    snaps = [snapshot(ds, key_mode) for ds in available]
    base = snaps[0]
    result = {
        "schema": "bbtwin.capability-diff/v1",
        "key_mode": key_mode,
        "baseline": base["dataset"],
        "datasets_used": [s["dataset"] for s in snaps],
        "datasets_skipped": skipped,
        "baseline_summary": base["ledger"]["summary"],
        "baseline_high_value_edges": [c for c in base["direct"].values()
                                      if c["target_high_value"]][:300],
        "comparisons": [],
        "boundary": "Static ACL facts compared across supplied exports; a capability is "
                    "not an executed action and dataset ownership is not asserted.",
    }
    for other in snaps[1:]:
        result["comparisons"].append(diff(base, other))

    (out / "capability-diff.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    (out / "CAPABILITY-DIFF.md").write_text(render(result), encoding="utf-8")
    print(json.dumps({"baseline": base["dataset"], "datasets_used": result["datasets_used"],
                      "datasets_skipped": skipped,
                      "comparisons": len(result["comparisons"]),
                      "report": str(out / "CAPABILITY-DIFF.md")}, indent=2))
    return 0


def render(result: dict) -> str:
    base = result["baseline"]
    lines = ["# BloodHound capability drift", "",
             f"- Baseline: **{base}**",
             f"- Compared: {', '.join(result['datasets_used'])}"]
    if result["datasets_skipped"]:
        sk = ", ".join(f"{s['name']} ({s['status']})" for s in result["datasets_skipped"])
        lines.append(f"- Skipped: {sk}")
    s = result["baseline_summary"]
    lines += ["", "## Baseline capability totals", "",
              f"- nodes/edges: `{s['principals_and_groups']}` / `{s['edges']}`",
              f"- direct: `{s['direct_capabilities']}` · inherited: `{s['inherited_capabilities']}` "
              f"· high-value edges: `{s['high_value_capability_edges']}`",
              f"- by type: `{s['capabilities_by_type']}`"]

    lines += ["", "## Identities holding control over a high-value target (baseline)", "",
              "| Identity | Capability | Target |", "|---|---|---|"]
    for c in result["baseline_high_value_edges"][:40]:
        lines.append(f"| {c['from']} | {c['capability']} | {c['to']} |")

    if not result["comparisons"]:
        lines += ["", "## Drift", "",
                  "_Only one dataset is available; no comparison yet. Add dataset paths to "
                  "`data/surface-agents/ad/datasets.json` (or supply them) and re-run._"]
    for cmp in result["comparisons"]:
        lines += ["", f"## {cmp['from']} → {cmp['to']}", "",
                  f"- added: `{cmp['counts']['added']}` · removed: `{cmp['counts']['removed']}` "
                  f"· unchanged: `{cmp['counts']['unchanged']}`", ""]
        if cmp["escalations"]:
            lines += ["**New control over a high-value target:**", "",
                      "| Identity | Capability | Target |", "|---|---|---|"]
            for e in cmp["escalations"]:
                lines.append(f"| {e['from']} | {e['capability']} | {e['to']} |")
            lines.append("")
        if cmp["reductions"]:
            lines += ["**Control removed (hardening):**", "",
                      "| Identity | Capability | Target |", "|---|---|---|"]
            for e in cmp["reductions"]:
                lines.append(f"| {e['from']} | {e['capability']} | {e['to']} |")
            lines.append("")
        top = list(cmp["identities_changed"].items())[:10]
        if top:
            lines += ["**Most-changed identities:** " +
                      ", ".join(f"{n} (+{d['gained']}/-{d['lost']})" for n, d in top), ""]
    lines += ["", "_Static ACL comparison only; no path executed. Ownership of the exports "
              "is not asserted._", ""]
    return "\n".join(lines)


if __name__ == "__main__":
    raise SystemExit(main())