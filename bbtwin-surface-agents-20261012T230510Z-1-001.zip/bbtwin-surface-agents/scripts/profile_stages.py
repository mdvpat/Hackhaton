#!/usr/bin/env python3
"""Stage-level profiling for the harness: where does the time actually go?

Times the four hot stages without any external profiler, so it runs anywhere
(laptop or Leonardo). Writes a JSON table and prints a readable one.

Usage:
  python3 scripts/profile_stages.py \
      --ad data/surface-agents/ad/company1 \
      --out data/surface-agents/runs/prof/stages.json [--repeats 3] [--docs 400]
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from harness.kg_client import AgentStore, HARNESS_ROOT, SharedVectors  # noqa: E402
from harness.surface_agent import capability_ledger, canonicalize_bloodhound  # noqa: E402

SYNTH = ("service account with an SPN, kerberoastable; authorization check on the "
         "order object; path traversal in archive extraction; SSRF to cloud metadata; "
         "stale cache permits a cross-tenant read; zip-slip write to the release dir")


def timed(fn, repeats: int) -> dict:
    samples = []
    value = None
    for _ in range(max(1, repeats)):
        start = time.perf_counter()
        value = fn()
        samples.append(time.perf_counter() - start)
    return {"median_s": round(statistics.median(samples), 6),
            "min_s": round(min(samples), 6), "repeats": len(samples), "value": value}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ad", default="data/surface-agents/ad/company1")
    ap.add_argument("--out", default="data/surface-agents/runs/prof/stages.json")
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--docs", type=int, default=400)
    ap.add_argument("--embedding-endpoint")
    ap.add_argument("--embedding-model")
    args = ap.parse_args()

    ad = Path(args.ad)
    if not ad.is_absolute():
        ad = HARNESS_ROOT / ad
    if not ad.exists():
        raise SystemExit(f"AD dataset not found: {ad}")

    results: dict = {"ad_dataset": str(ad), "embedding": None, "stages": {}}

    canon = timed(lambda: canonicalize_bloodhound(ad), 1)
    graph = canon.pop("value")
    results["stages"]["canonicalize_bloodhound"] = {**canon,
                                                    "nodes": len(graph["nodes"]),
                                                    "edges": len(graph["edges"])}

    ledger = timed(lambda: capability_ledger(graph), args.repeats)
    summary = ledger.pop("value")["summary"]
    results["stages"]["capability_ledger"] = {**ledger, **{
        "direct_capabilities": summary["direct_capabilities"],
        "inherited_capabilities": summary["inherited_capabilities"],
        "high_value_edges": summary["high_value_capability_edges"]}}

    # embedding + similarity over a synthetic corpus of the requested size
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        store = AgentStore(Path(tmp) / "prof.sqlite3")
        vectors = SharedVectors(store, args.embedding_endpoint, args.embedding_model)
        results["embedding"] = {"backend": vectors.backend, "docs": args.docs}
        docs = [f"{SYNTH} variant {i}" for i in range(args.docs)]

        def index():
            for i, body in enumerate(docs):
                vectors.add("prof", "AD", f"doc-{i}", body)
            return len(docs)

        results["stages"]["vectors_index"] = timed(index, 1)
        results["stages"]["vectors_search"] = timed(
            lambda: len(vectors.search("prof", "ssrf metadata cross-tenant", 5)["results"]),
            args.repeats)
        store.close()

    out = Path(args.out)
    if not out.is_absolute():
        out = HARNESS_ROOT / out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2), encoding="utf-8")

    print(f"{'stage':<26}{'median s':>12}{'min s':>12}  detail")
    for name, row in results["stages"].items():
        detail = " ".join(f"{k}={v}" for k, v in row.items()
                          if k not in ("median_s", "min_s", "repeats"))
        print(f"{name:<26}{row['median_s']:>12.4f}{row['min_s']:>12.4f}  {detail}")
    print(f"\nembedding backend: {results['embedding']['backend']}")
    print(f"wrote {out}")
    print("\nGPU port targets: vectors_index/vectors_search (batched embedding + cosine), "
          "capability_ledger (transitive closure + join).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())