#!/usr/bin/env python3
"""BloodHound capability report: who can do what to a crown-jewel target.

Reads a normalized graph (from `harness.surface_agent --canonicalize`) and the
capability ledger, then prints/writes the capabilities an identity holds and the
shortest capability path from each unprivileged user to a high-value target.

Read-only, static analysis of a supplied export. Nothing is executed.
Usage:
  python3 scripts/bh_capability_report.py \
      --graph data/surface-agents/runs/bh-check/normalized-graph.json \
      --ledger data/surface-agents/runs/bh-check/capability-ledger.json \
      --out data/surface-agents/runs/bh-check/CAPABILITIES.md
"""
from __future__ import annotations

import argparse
import json
from collections import deque
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from harness.surface_agent import (ACCESS_RIGHTS, CAPABILITY_RIGHTS, HIGH_VALUE_PATTERNS,  # noqa: E402
                                   SESSION_RIGHT, is_high_value)

TRAVERSABLE = CAPABILITY_RIGHTS | ACCESS_RIGHTS | {SESSION_RIGHT, "MEMBEROF"}
CONTROL = CAPABILITY_RIGHTS - {"ADMINTO"}  # rights that transfer control


def bfs(adj, sources, targets, max_depth=8):
    """Shortest labelled path from any source to any target."""
    best = None
    queue = deque((s, [s], []) for s in sources)
    seen = set(sources)
    while queue:
        node, path, labels = queue.popleft()
        if len(path) - 1 > max_depth:
            continue
        if node in targets and len(path) > 1:
            return {"path": path, "labels": labels}
        for nxt, label in adj.get(node, []):
            if nxt in seen:
                continue
            seen.add(nxt)
            queue.append((nxt, path + [nxt], labels + [label]))
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--graph", required=True)
    ap.add_argument("--ledger", required=True)
    ap.add_argument("--out")
    args = ap.parse_args()

    graph = json.loads(Path(args.graph).read_text())
    ledger = json.loads(Path(args.ledger).read_text())
    name = {n["id"]: n["name"] for n in graph["nodes"]}
    ntype = {n["id"]: n["type"] for n in graph["nodes"]}

    adj: dict[str, list] = {}
    for e in graph["edges"]:
        if e["type"] in TRAVERSABLE:
            adj.setdefault(e["src"], []).append((e["dst"], e["type"]))

    hv_targets = {n["id"] for n in graph["nodes"] if is_high_value(n["name"], n)}
    users = [n["id"] for n in graph["nodes"]
             if n["type"] == "USER" and not n["name"].startswith(("NT AUTHORITY", "NT SERVICE"))]

    lines = ["# BloodHound capability report", "",
             f"Source graph: `{args.graph}`", "",
             "## Capability totals", ""]
    for k, v in ledger["summary"].items():
        if k != "principals_reaching_high_value":
            lines.append(f"- **{k}**: `{v}`")

    lines += ["", "## Identities holding a direct-control capability", "",
              "| Principal | Capability | Target | High-value |", "|---|---|---|---|"]
    control = [c for c in ledger["direct_capabilities"]
               if c["capability"] in CONTROL and ntype.get(c["from"]["id"]) in ("USER", "GROUP")]
    for c in sorted(control, key=lambda c: (not c["target_high_value"], c["capability"])):
        hv = "yes" if c["target_high_value"] else ""
        lines.append(f"| {c['from']['name']} | {c['capability']} | {c['to']['name']} | {hv} |")

    lines += ["", "## Shortest capability path from an unprivileged user to a high-value target", ""]
    found = []
    for uid in users:
        res = bfs(adj, [uid], hv_targets)
        if res:
            found.append((uid, res))
    found.sort(key=lambda x: len(x[1]["path"]))
    if not found:
        lines.append("_No unprivileged user reaches a high-value target within depth 8._")
    for uid, res in found[:15]:
        chain = []
        for i, node in enumerate(res["path"]):
            chain.append(name.get(node, node))
            if i < len(res["labels"]):
                chain.append(f"--{res['labels'][i]}-->")
        lines.append(f"- **{name.get(uid, uid)}**: " + " ".join(chain))
    lines.append("")

    # Capability handoff packet other surfaces can consume.
    packet = {
        "schema": "bbtwin.capability-packet/v1",
        "source": "AD",
        "totals": ledger["summary"],
        "reachable_high_value_targets": ledger["reachable_high_value_targets"],
        "identities_with_domain_control": sorted({
            c["from"]["name"] for c in control
            if c["capability"] == "DCSYNC" or c["to"]["name"].upper().startswith(
                ("AD.COMPANY1@", "DOMAIN ADMINS", "ENTERPRISE ADMINS"))}),
        "paths_to_high_value": [
            {"from": name.get(uid, uid), "distance": len(res["path"]) - 1,
             "path": [name.get(n, n) for n in res["path"]], "capabilities": res["labels"]}
            for uid, res in found[:25]],
        "boundary": "Static ACL/access edges; a capability is not an executed action.",
    }
    out = Path(args.out) if args.out else None
    if out:
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
        out.with_suffix(".json").write_text(json.dumps(packet, indent=2), encoding="utf-8")
        print(json.dumps({"report": str(out), "packet": str(out.with_suffix('.json')),
                          "users_reaching_high_value": len(found)}, indent=2))
    else:
        print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())