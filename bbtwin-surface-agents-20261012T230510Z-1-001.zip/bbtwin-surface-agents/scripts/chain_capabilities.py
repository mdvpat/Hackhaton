#!/usr/bin/env python3
"""Evaluate cross-surface chain candidates against an AD capability ledger.

A chain is a claim of the form: ENTRY (a finding produces capability X) × the
ledger's AUTHORITY (an identity × right × target that can be spent) → crown jewel.

This tool does NOT claim a chain is real. It joins a candidate list against the
ledger and reports, per chain, whether the ledger side is ENABLED, BLOCKED, or
UNKNOWN, and what evidence is still owed. Chains are `assumed` until the entry
capability is demonstrated and the reachability join is proven.

Usage:
  python3 scripts/chain_capabilities.py \
      --ledger data/surface-agents/runs/leonardo-ad/AD/capability-ledger.json \
      --catalog ../BBTWINDOC/chain-catalog.json [--out chain-eval.json]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from harness.kg_client import HARNESS_ROOT  # noqa: E402


def facts_from_ledger(ledger: dict) -> dict:
    direct = ledger.get("direct_capabilities", [])
    reach = ledger.get("reachable_high_value_targets", {})
    summary = ledger.get("summary", {})

    def holders(capability, only_type=None):
        return sorted({c["from"]["name"] for c in direct
                       if c["capability"] == capability
                       and (only_type is None or c["from"]["type"] == only_type)})

    domain_admin_targets = [t for t in reach if "DOMAIN ADMINS" in t.upper()]
    da_members = sorted({p for t in domain_admin_targets for p in reach[t]})

    return {
        "dcsync_holders": holders("DCSYNC"),
        "dcsync_user_holders": holders("DCSYNC", "USER"),
        "adminto_edges": [c for c in direct if c["capability"] == "ADMINTO"],
        "domain_admin_members": da_members,
        "high_value_edges": summary.get("high_value_capability_edges", 0),
        "direct_capabilities": summary.get("direct_capabilities", 0),
        "reachable_targets": sorted(reach),
        "tier0_principals": sorted({c["from"]["name"] for c in direct
                                    if c["target_high_value"]
                                    and c["from"]["type"] in ("USER", "GROUP")}),
    }


# Each requirement is a predicate over the ledger facts; `needs` names the entry
# capability the finding must still supply.
REQUIREMENTS = {
    "user_holds_dcsync": lambda f: bool(f["dcsync_user_holders"]),
    "any_dcsync_holder": lambda f: bool(f["dcsync_holders"]),
    "user_in_domain_admins": lambda f: bool(f["domain_admin_members"]),
    "has_adminto_edge": lambda f: bool(f["adminto_edges"]),
    "high_value_edges_gte_1": lambda f: f["high_value_edges"] >= 1,
    "high_value_edges_gte_50": lambda f: f["high_value_edges"] >= 50,
}


def evaluate(ledger: dict, catalog: dict) -> dict:
    facts = facts_from_ledger(ledger)
    results = []
    for chain in catalog.get("chains", []):
        missing = [r for r in chain.get("requires_ledger", []) if r not in REQUIREMENTS]
        unmet = [r for r in chain.get("requires_ledger", [])
                 if r in REQUIREMENTS and not REQUIREMENTS[r](facts)]
        if missing:
            status, why = "UNKNOWN", f"unknown requirement(s): {missing}"
        elif unmet:
            status, why = "BLOCKED", f"ledger does not satisfy: {unmet}"
        else:
            status, why = "ENABLED", "ledger side holds; entry capability still owed"
        results.append({
            "id": chain.get("id"), "name": chain.get("name"),
            "combination": chain.get("combination"),
            "status": status, "why": why,
            "ledger_requirement": chain.get("requires_ledger", []),
            "entry_capability_needed": chain.get("entry_capability"),
            "evidence": chain.get("evidence", "assumed"),
            "crown_jewels": chain.get("crown_jewels", []),
        })

    order = {"ENABLED": 0, "UNKNOWN": 1, "BLOCKED": 2}
    results.sort(key=lambda r: order[r["status"]])
    return {
        "schema": "bbtwin.chain-eval/v1",
        "ledger_summary": ledger.get("summary", {}),
        "ledger_facts": {
            "dcsync_user_holders": facts["dcsync_user_holders"],
            "domain_admin_members": facts["domain_admin_members"],
            "adminto_edges": len(facts["adminto_edges"]),
            "high_value_edges": facts["high_value_edges"],
        },
        "enabled": [r["id"] for r in results if r["status"] == "ENABLED"],
        "chains": results,
        "boundary": "Ledger side only. An ENABLED chain still needs a DEMONSTRATED entry "
                    "capability and a proven reachability join; nothing here is a finding.",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ledger", required=True)
    ap.add_argument("--catalog", required=True)
    ap.add_argument("--out")
    args = ap.parse_args()

    def load(p):
        path = Path(p)
        if not path.is_absolute():
            path = (HARNESS_ROOT / path) if (HARNESS_ROOT / path).exists() else path
        return json.loads(path.read_text())

    ledger, catalog = load(args.ledger), load(args.catalog)
    report = evaluate(ledger, catalog)

    if args.out:
        Path(args.out).write_text(json.dumps(report, indent=2), encoding="utf-8")

    print(f"ledger facts: DCSync users={report['ledger_facts']['dcsync_user_holders']} "
          f"DA-members={report['ledger_facts']['domain_admin_members']} "
          f"ADMINTO={report['ledger_facts']['adminto_edges']} "
          f"high-value edges={report['ledger_facts']['high_value_edges']}\n")
    for c in report["chains"]:
        mark = {"ENABLED": "ENABLED ", "BLOCKED": "BLOCKED ", "UNKNOWN": "UNKNOWN "}[c["status"]]
        print(f"[{mark}] {c['id']}  {c['name']}")
        print(f"          combo : {c['combination']}")
        print(f"          needs : {c['entry_capability_needed']}  ({c['evidence']})")
        print(f"          why   : {c['why']}")
    print(f"\nenabled: {report['enabled']}")
    print("A chain is a candidate until the entry capability is demonstrated and the "
          "reachability join is proven.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())