#!/usr/bin/env python3
"""Anonymize a SharpHound v5 export.

Rewrites the domain to AD.COMPANY1, randomizes user/computer/custom-group
names, and remaps the domain SID prefix — while preserving RIDs and well-known
group names so the capability and high-value logic still apply. Deterministic
for a given --seed.

A local mapping file is written for the operator. It reverses the anonymization
and is SENSITIVE: never share it with the anonymized export.

Usage:
  python3 scripts/bh_anonymize.py \
      --input  data/surface-agents/ad/company1 \
      --out    data/surface-agents/ad/company1 \
      --domain AD.COMPANY1 --seed bbtwin
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

# Well-known / builtin names kept verbatim: they are standard AD vocabulary, not
# identifying, and the high-value target logic depends on them.
WELL_KNOWN = {
    "DOMAIN ADMINS", "ENTERPRISE ADMINS", "SCHEMA ADMINS", "DOMAIN USERS",
    "DOMAIN COMPUTERS", "DOMAIN CONTROLLERS", "ADMINISTRATORS", "ACCOUNT OPERATORS",
    "SERVER OPERATORS", "BACKUP OPERATORS", "PRINT OPERATORS", "ENTERPRISE KEY ADMINS",
    "KRBTGT", "GUEST", "PROTECTED USERS", "READ-ONLY DOMAIN CONTROLLERS", "DNSADMINS",
    "DNSUPDATEPROXY", "GROUP POLICY CREATOR OWNERS", "CLONEABLE DOMAIN CONTROLLERS",
    "REMOTE DESKTOP USERS", "REMOTE MANAGEMENT USERS", "PERFORMANCE LOG USERS",
    "PERFORMANCE MONITOR USERS", "EVENT LOG READERS", "HYPER-V ADMINISTRATORS",
    "NETWORK CONFIGURATION OPERATORS", "WINDOWS AUTHORIZATION ACCESS GROUP",
    "CERTIFICATE SERVICE DCOM ACCESS", "IIS_IUSRS", "USERS", "COMPUTERS", "SYSTEM",
    "POLICIES", "DOMAIN CONTROLLERS", "MICROSOFT EXCHANGE", "SERVICE ACCOUNTS",
    "NT AUTHORITY", "NT SERVICE", "IUSR", "DEFAULTACCOUNT",
}

PREFIX = {"USER": "USER", "COMPUTER": "HOST", "GROUP": "GROUP", "OU": "OU",
          "GPO": "GPO", "CONTAINER": "CN", "DOMAIN": "DOMAIN"}
SID_KEYS = {"ObjectIdentifier", "PrincipalSID", "PrincipalId", "SID", "Sid",
            "PrimaryGroupSID", "ObjectId", "ObjectID", "UserSID", "ComputerSID",
            "objectid", "SidHistory", "sidhistory", "domainsid",
            "domainSid", "DomainSID"}
NAME_KEYS = {"name", "Name", "samaccountname", "displayname", "DisplayName"}
DN_KEYS = {"distinguishedname", "distinguishedName", "dn", "DN"}
DESC_KEYS = {"description", "Description", "info", "note"}
SID_RE = re.compile(r"^(S-1-5-\d+(-\d+)*)$", re.IGNORECASE)


def rid_of(sid: str) -> str:
    parts = str(sid).split("-")
    for part in reversed(parts):
        if part.isdigit():
            return part
    return str(sid)


def slug(seed: str, token: str, n: int = 4) -> str:
    return hashlib.sha256(f"{seed}:{token}".encode()).hexdigest()[:n].upper()


def load_records(src: Path) -> list[dict]:
    files = []
    for path in sorted(src.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        files.append((path, doc))
    return files


def build_maps(files, new_domain: str, seed: str):
    old_domain = None
    old_sid = None
    objects = {}  # oid -> (type, leaf_name)
    for _, doc in files:
        ftype = (doc.get("meta") or {}).get("type")
        for rec in doc.get("data") or []:
            oid = rec.get("ObjectIdentifier")
            props = rec.get("Properties") or {}
            if not oid:
                continue
            if ftype == "domains":
                old_domain = props.get("domain") or old_domain
                old_sid = oid if str(oid).startswith("S-1-5-21-") else old_sid
            objects[oid] = (ftype, str(props.get("name") or oid))
    if not old_domain or not old_sid:
        raise SystemExit("could not determine the source domain and domain SID")

    new_sid = "S-1-5-21-" + "-".join(
        str(int(slug(seed, "dsid" + str(i), 8), 16) % 4_000_000_000) for i in range(3))

    name_map, sid_map, type_map = {}, {}, {}
    for oid, (ftype, name) in objects.items():
        kind = {"users": "USER", "computers": "COMPUTER", "groups": "GROUP",
                "ous": "OU", "gpos": "GPO", "containers": "CONTAINER",
                "domains": "DOMAIN"}.get(ftype, "OBJECT")
        type_map[oid] = kind
        sid_map[oid] = remap_sid(oid, old_domain, old_sid, new_domain, new_sid)
        rid = rid_of(oid)
        builtin = rid.isdigit() and int(rid) < 1000
        base = name.split("@")[0]
        if kind == "DOMAIN":
            label = new_domain
        elif (base.upper() in WELL_KNOWN) or builtin:
            label = base                                  # standard vocabulary kept
        else:
            label = f"{PREFIX.get(kind, 'OBJ')}-{slug(seed, oid)}"
        # Alias every form the export uses: full name, pre-@, pre-dot, $-suffixed.
        for alias in {name.upper(), base.upper(), base.split(".")[0].upper(),
                      base.rstrip("$").upper(), base.split(".")[0].rstrip("$").upper()}:
            if alias:
                name_map[alias] = label
    return old_domain, old_sid, new_domain, new_sid, name_map, sid_map, type_map


def lookup_name(value: str, name_map: dict):
    """Resolve any name form the export uses to its assigned label."""
    if not isinstance(value, str) or not value.strip():
        return None
    for candidate in (value, value.split("@")[0], value.rstrip("$"),
                      value.split("@")[0].split(".")[0], value.split("@")[0].rstrip("$")):
        got = name_map.get(candidate.strip().upper())
        if got:
            return got
    return None


def remap_sid(sid, old_domain, old_sid, new_domain, new_sid):
    if not isinstance(sid, str) or not sid:
        return sid
    if sid.startswith(old_sid + "-"):
        return new_sid + sid[len(old_sid):]           # RID preserved
    if sid.startswith(old_sid):
        return new_sid
    if sid.upper().startswith(old_domain.upper() + "-"):
        return new_domain + sid[len(old_domain):]
    return sid


def rewrite_dn(dn, old_domain, new_domain, name_map):
    if not isinstance(dn, str):
        return dn
    parts = []
    for component in dn.split(","):
        head, _, value = component.partition("=")
        key = head.strip().upper()
        if key == "DC":
            if value.strip().upper() == old_domain.split(".")[0].upper():
                parts.append(f"{head}=AD")
            elif value.strip().upper() == old_domain.split(".")[-1].upper():
                parts.append(f"{head}=COMPANY1")
            else:
                parts.append(component)
        elif key in {"CN", "OU"} and value.strip().upper() in name_map:
            parts.append(f"{head}={name_map[value.strip().upper()]}")
        else:
            parts.append(component)
    return ",".join(parts)


def scrub(text, old_domain, name_map):
    if not isinstance(text, str):
        return text
    out = text.replace(old_domain, "AD.COMPANY1")
    out = out.replace(old_domain.split(".")[0], "AD")
    for token in sorted((k for k in name_map if len(k) > 3), key=len, reverse=True):
        out = re.sub(re.escape(token), name_map[token], out, flags=re.IGNORECASE)
    return out


def rewrite(node, ctx):
    if isinstance(node, str):
        # Bare strings inside lists (SPNs, SPNTargets, sidhistory): remap SIDs,
        # scrub any embedded identifier.
        return ctx["remap_sid"](node) if SID_RE.match(node) else \
            scrub(node, ctx["old_domain"], ctx["name_map"])
    if isinstance(node, list):
        return [rewrite(item, ctx) for item in node]
    if not isinstance(node, dict):
        return node
    out = {}
    for key, value in node.items():
        if key in SID_KEYS and isinstance(value, str):
            out[key] = ctx["remap_sid"](value)
        elif key in DN_KEYS and isinstance(value, str):
            out[key] = rewrite_dn(value, ctx["old_domain"], ctx["new_domain"], ctx["name_map"])
        elif key in {"domain", "Domain"} and isinstance(value, str):
            out[key] = (ctx["new_domain"]
                        if value.strip().upper() == ctx["old_domain"].upper()
                        else scrub(value, ctx["old_domain"], ctx["name_map"]))
        elif key in NAME_KEYS and isinstance(value, str):
            trailing = "$" if value.endswith("$") else ""
            has_at = "@" in value
            mapped = lookup_name(value, ctx["name_map"])
            if mapped:
                out[key] = f"{mapped}{trailing}" + (f"@{ctx['new_domain']}" if has_at else "")
            else:
                out[key] = scrub(value, ctx["old_domain"], ctx["name_map"])
        elif isinstance(value, str):
            # SPNs, dnshostname, gpcpath, descriptions: scrub identifiers too.
            out[key] = scrub(value, ctx["old_domain"], ctx["name_map"])
        else:
            out[key] = rewrite(value, ctx)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--domain", default="AD.COMPANY1")
    ap.add_argument("--seed", default="bbtwin")
    ap.add_argument("--mapping")
    args = ap.parse_args()

    src, dst = Path(args.input), Path(args.out)
    files = load_records(src)
    old_domain, old_sid, new_domain, new_sid, name_map, sid_map, type_map = build_maps(
        files, args.domain, args.seed)

    ctx = {"old_domain": old_domain, "new_domain": new_domain, "name_map": name_map,
           "remap_sid": lambda s: remap_sid(s, old_domain, old_sid, new_domain, new_sid)}

    dst.mkdir(parents=True, exist_ok=True)
    counts = {}
    for path, doc in files:
        # Rewrite only the object records: `meta` carries the SharpHound file
        # type that the canonicalizer depends on and must stay verbatim.
        new_doc = dict(doc)
        if isinstance(doc.get("data"), list):
            new_doc["data"] = [rewrite(item, ctx) for item in doc["data"]]
        (dst / path.name.replace(old_domain.split(".")[0], "company1")).write_text(
            json.dumps(new_doc, indent=1), encoding="utf-8")
        counts[(doc.get("meta") or {}).get("type")] = len(doc.get("data") or [])

    mapping = {"schema": "bbtwin.anonymization-map/v1", "SENSITIVE": True,
               "old_domain": old_domain, "new_domain": new_domain,
               "old_domain_sid": old_sid, "new_domain_sid": new_sid,
               "note": "LOCAL ONLY - reverses the anonymization; never share.",
               "objects": [{"sid_old": o, "sid_new": sid_map[o], "type": type_map[o],
                            "name_old": name, "name_new": name_map.get(str(name).upper(), name)}
                           for o, name in
                           sorted(((o, str(p.get("Properties", {}).get("name") or o))
                                   for _, d in files for p in (d.get("data") or [])
                                   for o in [p.get("ObjectIdentifier")] if o),
                                  key=lambda x: x[0])]}
    map_path = Path(args.mapping) if args.mapping else dst / "anonymization-mapping.SENSITIVE.json"
    map_path.write_text(json.dumps(mapping, indent=2), encoding="utf-8")
    print(json.dumps({"out": str(dst), "old_domain": old_domain, "new_domain": new_domain,
                      "new_domain_sid": new_sid, "files": len(files), "objects": counts,
                      "mapping": str(map_path)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())