#!/usr/bin/env python3
"""Mock AD agent <-> orchestrator message exchange for one AD set.

Runs the REAL AD pipeline (canonicalize -> capability ledger -> shortest
capability paths) and emits the orchestrator/agent conversation through the real
AgentStore, so the transcript has production schema and production numbers.

Usage:
  python3 scripts/mock_ad_orchestrator.py [--ad data/surface-agents/ad/company1] \
      [--run mock-ad-1] [--out data/surface-agents/runs]
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import deque
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from harness.kg_client import AgentStore, HARNESS_ROOT  # noqa: E402
from harness.surface_agent import (ACCESS_RIGHTS, CAPABILITY_RIGHTS, SESSION_RIGHT,  # noqa: E402
                                  capability_ledger, canonicalize_bloodhound, is_high_value)

TRAVERSABLE = CAPABILITY_RIGHTS | ACCESS_RIGHTS | {SESSION_RIGHT, "MEMBEROF"}
CONTROL = CAPABILITY_RIGHTS - {"ADMINTO"}


def shortest_paths(graph, max_results=8, max_depth=8):
    """Shortest labelled capability path from each unprivileged user to a crown jewel."""
    name = {n["id"]: n["name"] for n in graph["nodes"]}
    high_value = {n["id"] for n in graph["nodes"] if is_high_value(n["name"], n)}
    users = [n["id"] for n in graph["nodes"]
             if n["type"] == "USER" and not n["name"].startswith(("NT AUTHORITY", "NT SERVICE"))]
    adjacency: dict[str, list] = {}
    for edge in graph["edges"]:
        if edge["type"] in TRAVERSABLE:
            adjacency.setdefault(edge["src"], []).append((edge["dst"], edge["type"]))

    found = []
    for user in users:
        queue = deque([(user, [user], [])])
        seen = {user}
        while queue:
            node, path, labels = queue.popleft()
            if len(path) - 1 > max_depth:
                continue
            if node in high_value and len(path) > 1:
                found.append({"from": name[user], "to": name[node], "distance": len(path) - 1,
                              "path": [name[n] for n in path], "capabilities": labels})
                break
            for nxt, label in adjacency.get(node, []):
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append((nxt, path + [nxt], labels + [label]))
    found.sort(key=lambda r: r["distance"])
    return found[:max_results]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ad", default=None, help="AD dataset dir (default: config AD input)")
    ap.add_argument("--run", default="mock-ad-1")
    ap.add_argument("--out", default="data/surface-agents/runs")
    ap.add_argument("--objective", default="Enumerate AD capabilities and crown-jewel paths.")
    args = ap.parse_args()

    config = json.loads((HARNESS_ROOT / "harness" / "surface_agents.json").read_text())
    ad = Path(args.ad) if args.ad else (HARNESS_ROOT / "data" / "surface-agents"
                                        / config["surfaces"]["AD"]["input"])
    if not ad.is_absolute():
        ad = HARNESS_ROOT / ad
    if not ad.exists():
        raise SystemExit(f"AD dataset not found: {ad}")

    graph = canonicalize_bloodhound(ad)
    ledger = capability_ledger(graph)
    summary = ledger["summary"]
    control = sorted({c["from"]["name"] for c in ledger["direct_capabilities"]
                      if c["capability"] in CONTROL and c["target_high_value"]})
    dcsync = sorted({c["from"]["name"] for c in ledger["direct_capabilities"]
                     if c["capability"] == "DCSYNC"})
    paths = shortest_paths(graph)

    out_root = Path(args.out)
    if not out_root.is_absolute():
        out_root = HARNESS_ROOT / out_root
    workspace = out_root.parent
    store = AgentStore(workspace / "agent_kg.sqlite3")
    run = args.run
    budget = int(config.get("max_attempts", 5))

    def say(src, dst, topic, body):
        store.send(run, src, dst, topic, body)

    # -- orchestrator <-> AD conversation -------------------------------- #
    say("coordinator", "AD", "task.assign", {
        "objective": args.objective, "dataset": str(ad), "attempt_budget": budget,
        "constraints": ["read-only", "local dataset only", "claim requires falsifier + refs"]})
    say("AD", "coordinator", "task.ack", {"accepted": True, "surface": "AD",
                                          "attempts_remaining": budget})
    say("AD", "coordinator", "probe.result", {
        "canonical": {"nodes": len(graph["nodes"]), "edges": len(graph["edges"])},
        "dataset": str(ad)})
    say("AD", "all", "AD:capabilities", {
        "schema": "bbtwin.capability-packet/v1",
        "direct_capabilities": summary["direct_capabilities"],
        "inherited_capabilities": summary["inherited_capabilities"],
        "high_value_edges": summary["high_value_capability_edges"],
        "identities_with_direct_control": control,
        "capabilities_by_type": summary["capabilities_by_type"]})
    say("coordinator", "AD", "request.detail", {"query": "shortest paths to crown jewels"})
    say("AD", "coordinator", "result.detail", {"paths": paths})
    say("AD", "coordinator", "claim", {
        "attempt": 1, "status": "supported",
        "hypothesis": f"{len(paths)} unprivileged identities reach a high-value target",
        "falsifier": "run the path finder with --target-mode all; no path found => false",
        "source_refs": ["normalized-graph.json", "capability-ledger.json"],
        "evidence": {"dcsync_holders": dcsync, "control_holders": control}})
    say("coordinator", "all", "capabilities.distribute",
        {"from": "AD", "identities_with_direct_control": control, "dcsync": dcsync})
    say("AD", "coordinator", "handoff", {
        "outcome": "resolved", "attempts_used": 1, "attempts_max": budget,
        "done": ["canonicalized the AD export", "built the capability ledger",
                 "ranked crown-jewel paths"],
        "left": ["attribute capabilities to WEB/API/OSS surfaces",
                 "confirm reachability with a causal control before calling it a finding"],
        "artifacts": ["normalized-graph.json", "capability-ledger.json"]})
    say("coordinator", "AD", "task.close", {"run": run, "status": "resolved"})

    log = store.traffic(run, limit=100)
    body_by_id = {m["id"]: None for m in log}
    rows = store.db.execute("SELECT id,src,dst,type,body FROM messages WHERE run=? ORDER BY id",
                            (run,)).fetchall()

    run_dir = out_root / run
    run_dir.mkdir(parents=True, exist_ok=True)
    lines = [f"# Mock AD agent <-> orchestrator — run {run}", "",
             f"Dataset: `{ad}`", f"Budget: {budget} attempts", ""]
    jsonl = []
    for i, row in enumerate(rows):
        payload = json.loads(row["body"])
        lines.append(f"[{i:02d}] {row['src']:>11} -> {row['dst']:<11} {row['type']}")
        compact = json.dumps(payload)
        lines.append(f"      {compact[:240]}{'…' if len(compact) > 240 else ''}")
        jsonl.append({"seq": i, "from": row["src"], "to": row["dst"],
                      "topic": row["type"], "body": payload})
    lines += ["", f"messages: {len(rows)}  |  dcsync holders: {dcsync}",
              f"control holders: {control}", f"crown-jewel paths: {len(paths)}", ""]
    (run_dir / "mock-ad-orchestrator.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (run_dir / "mock-ad-orchestrator.jsonl").write_text(
        "\n".join(json.dumps(x) for x in jsonl) + "\n", encoding="utf-8")

    print("\n".join(lines))
    print(f"wrote {run_dir/'mock-ad-orchestrator.md'}")
    store.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())