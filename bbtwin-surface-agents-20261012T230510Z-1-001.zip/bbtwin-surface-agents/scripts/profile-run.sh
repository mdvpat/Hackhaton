#!/usr/bin/env bash
# Profile the harness. Works anywhere; uses Nsight Systems when present.
#
# Usage:
#   bash scripts/profile-run.sh            # stage table (no GPU needed)
#   bash scripts/profile-run.sh --nsys <run-id>   # Nsight Systems timeline + stats
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [ "${1:-}" = "--nsys" ]; then
  RUN="${2:-prof}"
  OUT="data/surface-agents/runs/prof/$RUN"
  mkdir -p "$OUT"
  if ! command -v nsys >/dev/null 2>&1; then
    echo "nsys not found (load the Nsight module, e.g. 'module load nsight-systems')." >&2
    echo "Falling back to scripts/profile_stages.py" >&2
    exec python3 scripts/profile_stages.py --out "$OUT/stages.json"
  fi
  echo "== nsys timeline =="
  nsys profile --trace=cuda,nvtx,osrt,python \
    --force-overwrite true \
    --output "$OUT/$RUN" \
    python3 -m harness.agent_bus --run "$RUN"
  echo "== nsys stats =="
  nsys stats --report cuda_gpu_kern_sum,nvtx_sum,osrt_sum "$OUT/$RUN.nsys-rep" | tee "$OUT/$RUN.stats.txt"
  echo "wrote $OUT"
  exit 0
fi

mkdir -p data/surface-agents/runs/prof
echo "== stage timings (CPU) =="
python3 scripts/profile_stages.py --out data/surface-agents/runs/prof/stages.json

cat <<'EOF'

Next (on Leonardo, inside an interactive GPU shell):
  module avail nsight 2>&1 | head
  bash scripts/profile-run.sh --nsys leonardo-prof
  ncu --set full -k <kernel-regex> python3 scripts/profile_stages.py

Attribute the four stages in the timeline, then port in this order:
  1. vectors_index / vectors_search  -> PyTorch or cuVS
  2. capability_ledger closure+join  -> cuGraph / cuDF
  3. model prefill/decode            -> already GPU; profile, don't port
EOF