#!/usr/bin/env bash
# "Compile" the harness: byte-compile, verify imports, and build a wheel if the
# build tooling is present. Safe to run on the login node or inside a job.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "== byte-compile (syntax + write .pyc) =="
python3 -m compileall -q harness scripts tests
echo "   ok: harness scripts tests"

echo "== import smoke =="
python3 - <<'EOF'
import importlib
mods = ["harness.kg_client", "harness.surface_agent", "harness.agent_bus",
        "harness.surface_bus_mcp", "harness.proxy", "harness.knowledge_memory"]
for name in mods:
    importlib.import_module(name)
    print(f"   ok: {name}")
EOF

echo "== tests =="
python3 -m unittest tests.test_surface_agent_bus 2>&1 | tail -3

if python3 -c "import build" >/dev/null 2>&1; then
  echo "== wheel =="
  python3 -m build --wheel --outdir dist 2>&1 | tail -3
  ls -la dist/ | sed 's/^/   /'
else
  echo "== wheel skipped (python3 -m build not installed; 'pixi add build' if wanted) =="
fi

echo
echo "compile ok. Compiled caches live next to the sources (__pycache__)."