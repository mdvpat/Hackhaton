"""Shared AD-set communication exchange + validation (used by the mock and the checker).

One place that defines the orchestrator <-> AD conversation, so the demo
generator and the validator can never drift apart.
"""
from __future__ import annotations

from collections import deque
from pathlib import Path

from harness.kg_client import HARNESS_ROOT
from harness.surface_agent import (ACCESS_RIGHTS, CAPABILITY_RIGHTS, SESSION_RIGHT,
                                  capability_ledger, canonicalize_bloodhound, is_high_value)

TRAVERSABLE = CAPABILITY_RIGHTS | ACCESS_RIGHTS | {SESSION_RIGHT, "MEMBEROF"}
CONTROL = CAPABILITY_RIGHTS - {"ADMINTO"}

REQUIRED_SEQUENCE = [
    ("coordinator", "AD", "task.assign"),
    ("AD", "coordinator", "task.ack"),
    ("AD", "coordinator", "probe.result"),
    ("AD", "all", "AD:capabilities"),
    ("coordinator", "AD", "request.detail"),
    ("AD", "coordinator", "result.detail"),
    ("AD", "coordinator", "claim"),
    ("coordinator", "all", "capabilities.distribute"),
    ("AD", "coordinator", "handoff"),
    ("coordinator", "AD", "task.close"),
]


def resolve_ad(ad_path=None, config_path=None) -> Path:
    import json
    config_file = Path(config_path) if config_path else HARNESS_ROOT / "harness" / "surface_agents.json"
    config = json.loads(config_file.read_text())
    ad = Path(ad_path) if ad_path else (HARNESS_ROOT / "data" / "surface-agents"
                                        / config["surfaces"]["AD"]["input"])
    if not ad.is_absolute():
        ad = HARNESS_ROOT / ad
    if not ad.exists():
        raise SystemExit(f"AD dataset not found: {ad}")
    return ad


def shortest_paths(graph, max_results=8, max_depth=8):
    """Shortest labelled capability path from each unprivileged user to a crown jewel."""
    name = {n["id"]: n["name"] for n in graph["nodes"]}
    high_value = {n["id"] for n in graph["nodes"] if is_high_value(n["name"], n)}
    users = [n["id"] for n in graph["nodes"]
             if n["type"] == "USER" and not n["name"].startswith(("NT AUTHORITY", "NT SERVICE"))]
    adjacency: dict[str, list] = {}
    for edge in graph["edges"]:
        if edge["type"] in TRAVERSABLE:
            adjacency.setdefault(edge["src"], []).append((edge["dst"], edge["type"]))
    found = []
    for user in users:
        queue = deque([(user, [user], [])])
        seen = {user}
        while queue:
            node, path, labels = queue.popleft()
            if len(path) - 1 > max_depth:
                continue
            if node in high_value and len(path) > 1:
                found.append({"from": name[user], "to": name[node], "distance": len(path) - 1,
                              "path": [name[n] for n in path], "capabilities": labels})
                break
            for nxt, label in adjacency.get(node, []):
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append((nxt, path + [nxt], labels + [label]))
    found.sort(key=lambda r: r["distance"])
    return found[:max_results]


def load_ad(ad_path: Path) -> dict:
    graph = canonicalize_bloodhound(ad_path)
    ledger = capability_ledger(graph)
    summary = ledger["summary"]
    return {
        "dataset": str(ad_path),
        "graph": graph,
        "ledger": ledger,
        "summary": summary,
        "control_holders": sorted({c["from"]["name"] for c in ledger["direct_capabilities"]
                                   if c["capability"] in CONTROL and c["target_high_value"]}),
        "dcsync_holders": sorted({c["from"]["name"] for c in ledger["direct_capabilities"]
                                  if c["capability"] == "DCSYNC"}),
        "paths": shortest_paths(graph),
    }


def exchange(store, run: str, ad: dict, objective: str, budget: int) -> None:
    """Emit the AD-set conversation through the real AgentStore."""
    def say(src, dst, topic, body):
        store.send(run, src, dst, topic, body)

    say("coordinator", "AD", "task.assign", {
        "objective": objective, "dataset": ad["dataset"], "attempt_budget": budget,
        "constraints": ["read-only", "local dataset only", "claim requires falsifier + refs"]})
    say("AD", "coordinator", "task.ack", {"accepted": True, "surface": "AD",
                                          "attempts_remaining": budget})
    say("AD", "coordinator", "probe.result", {
        "canonical": {"nodes": len(ad["graph"]["nodes"]), "edges": len(ad["graph"]["edges"])},
        "dataset": ad["dataset"]})
    say("AD", "all", "AD:capabilities", {
        "schema": "bbtwin.capability-packet/v1",
        "direct_capabilities": ad["summary"]["direct_capabilities"],
        "inherited_capabilities": ad["summary"]["inherited_capabilities"],
        "high_value_edges": ad["summary"]["high_value_capability_edges"],
        "identities_with_direct_control": ad["control_holders"],
        "capabilities_by_type": ad["summary"]["capabilities_by_type"]})
    say("coordinator", "AD", "request.detail", {"query": "shortest paths to crown jewels"})
    say("AD", "coordinator", "result.detail", {"paths": ad["paths"]})
    say("AD", "coordinator", "claim", {
        "attempt": 1, "status": "supported",
        "hypothesis": f"{len(ad['paths'])} unprivileged identities reach a high-value target",
        "falsifier": "run the path finder with --target-mode all; no path found => false",
        "source_refs": ["normalized-graph.json", "capability-ledger.json"],
        "evidence": {"dcsync_holders": ad["dcsync_holders"],
                     "control_holders": ad["control_holders"]}})
    say("coordinator", "all", "capabilities.distribute",
        {"from": "AD", "identities_with_direct_control": ad["control_holders"],
         "dcsync": ad["dcsync_holders"]})
    say("AD", "coordinator", "handoff", {
        "outcome": "resolved", "attempts_used": 1, "attempts_max": budget,
        "done": ["canonicalized the AD export", "built the capability ledger",
                 "ranked crown-jewel paths"],
        "left": ["attribute capabilities to WEB/API/OSS surfaces",
                 "confirm reachability with a causal control before calling it a finding"],
        "artifacts": ["normalized-graph.json", "capability-ledger.json"]})
    say("coordinator", "AD", "task.close", {"run": run, "status": "resolved"})


def rows_for(store, run: str) -> list[dict]:
    import json
    out = []
    for row in store.db.execute("SELECT id,src,dst,type,body FROM messages WHERE run=? "
                                "ORDER BY id", (run,)):
        out.append({"seq": row["id"], "from": row["src"], "to": row["dst"],
                    "topic": row["type"], "body": json.loads(row["body"])})
    return out


def validate(rows: list[dict], budget: int) -> dict:
    """Assert the AD-set conversation is well formed. Returns a report."""
    problems: list[str] = []
    checks: list[dict] = []

    def check(name, ok, detail=""):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        if not ok:
            problems.append(f"{name}: {detail}" if detail else name)

    valid_endpoints = {"coordinator", "AD", "WEB", "API", "OSS", "all"}
    bad = [r for r in rows if r["from"] not in valid_endpoints or r["to"] not in valid_endpoints]
    check("endpoints_valid", not bad, f"{len(bad)} message(s) with an unknown endpoint")

    topics = [(r["from"], r["to"], r["topic"]) for r in rows]
    missing = [t for t in REQUIRED_SEQUENCE if t not in topics]
    check("required_sequence_present", not missing, f"missing: {missing}")
    positions = [topics.index(t) for t in REQUIRED_SEQUENCE if t in topics]
    check("sequence_order", positions == sorted(positions),
          "required messages out of order")

    caps = [r for r in rows if r["topic"] == "AD:capabilities"]
    check("capabilities_broadcast_once", len(caps) == 1,
          f"{len(caps)} capabilities broadcast(s)")
    if caps:
        body = caps[0]["body"]
        check("capabilities_targets_all", caps[0]["to"] == "all", caps[0]["to"])
        check("capabilities_schema", body.get("schema") == "bbtwin.capability-packet/v1",
              str(body.get("schema")))
        check("capabilities_has_identities", bool(body.get("identities_with_direct_control")),
              "no identities listed")

    claims = [r for r in rows if r["topic"] == "claim"]
    check("claims_have_falsifier", all(str(c["body"].get("falsifier", "")).strip() for c in claims),
          "a claim has no falsifier")
    check("claims_have_source_refs", all(c["body"].get("source_refs") for c in claims),
          "a claim has no source refs")
    check("claims_within_budget", all(int(c["body"].get("attempt", 0)) <= budget for c in claims),
          f"an attempt exceeds the budget of {budget}")

    handoffs = [r for r in rows if r["topic"] == "handoff"]
    check("handoff_present", len(handoffs) == 1, f"{len(handoffs)} handoff(s)")
    if handoffs:
        body = handoffs[0]["body"]
        check("handoff_has_done_and_left", bool(body.get("done")) and bool(body.get("left")),
              "handoff missing done/left")
        check("handoff_attempts_recorded", body.get("attempts_used") is not None,
              "handoff has no attempts_used")

    # AD must be able to consume what is addressed to it (inbox path works)
    addressed = [r for r in rows if r["to"] in ("AD", "all") and r["from"] != "AD"]
    check("ad_is_addressable", len(addressed) >= 3, f"only {len(addressed)} message(s) to AD")

    return {"ok": not problems, "problems": problems, "checks": checks,
            "messages": len(rows), "topics": [r["topic"] for r in rows]}